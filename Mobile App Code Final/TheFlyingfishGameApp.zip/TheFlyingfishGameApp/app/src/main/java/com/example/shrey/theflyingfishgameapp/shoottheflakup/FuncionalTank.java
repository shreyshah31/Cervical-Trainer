package com.example.shrey.theflyingfishgameapp.shoottheflakup;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.util.DisplayMetrics;
import android.util.Log;

import androidx.core.util.Pair;

import com.example.shrey.theflyingfishgameapp.R;

import static android.content.ContentValues.TAG;
import static com.example.shrey.theflyingfishgameapp.shoottheflakup.ShootingGameActivity.editangle;

public class FuncionalTank extends GraphicComponent {

    public static final int TANK_BOTTOM_MARGIN = (ShootingGameActivity.mscreenheight / 100);
    private static final int TANK_LEFT_MARGIN = (int) (ShootingGameActivity.mscreenwidth / 2f);
    private static final int TANK_HEIGHT = ShootingGameActivity.mscreenheight / 6;
    private static final int TANK_WIDTH = ShootingGameActivity.mscreenheight / 6;

    private static final int GUNBARREL_LENGTH = ShootingGameActivity.mscreenheight / 3;
    private static final int GUNBARREL_WIDTH = ShootingGameActivity.mscreenheight / 12;

    private static final int STATUS_IDLE = 0;
    private static final int STATUS_POWERING = 1;
    private static final long POWERING_TIMER_LIMIT = 1200;

    private static Bitmap tankImg;
    private static Bitmap gunBarrelImg;

    private final GameEvents thread;
    private final float shootOriginX;
    private final float shootOriginY;
    private final float tankLeft;
    private final float tankTop;
    private final float gunBarrelTop;
    private final float gunBarrelLeft;

    private int tankStatus;
    private long milisecondsPowering;
    private Pair<Integer, Integer> bulletOrigin;
    public static float angle;
    private int power;
    private int lastBulletPower;
    private float angleBarrel;

    public FuncionalTank(DisplayMetrics metrics, GameThread thread, Resources res) {
        super(res, metrics);
        this.thread = thread;
        tankStatus = STATUS_IDLE;
        power = 0;
        lastBulletPower = 0;
        milisecondsPowering = 0;
        gunBarrelTop = ShootingGameActivity.mscreenheight - 1.6f*( TANK_HEIGHT );
        gunBarrelLeft = TANK_LEFT_MARGIN - GUNBARREL_WIDTH/2;
        tankLeft = TANK_LEFT_MARGIN - TANK_WIDTH/2;
        tankTop = ShootingGameActivity.mscreenheight - (TANK_HEIGHT );
        shootOriginX = TANK_LEFT_MARGIN;
        shootOriginY = tankTop + GUNBARREL_WIDTH ;
        setTarget(ShootingGameActivity.mscreenwidth, 0);
        tankImg = owninitBitmap(tankImg, R.drawable.cannonbase, TANK_WIDTH, TANK_HEIGHT);
        gunBarrelImg = owninitBitmap(gunBarrelImg, R.drawable.cannonbarrel, GUNBARREL_WIDTH, GUNBARREL_LENGTH);
    }


    public void update(long elapsedTime) {
        if (tankStatus == STATUS_POWERING) {
            milisecondsPowering = milisecondsPowering + elapsedTime;
            if (milisecondsPowering > POWERING_TIMER_LIMIT)
                milisecondsPowering = 0;
            power = (int) (((float) milisecondsPowering / POWERING_TIMER_LIMIT) * 100);
            Log.d(TAG, "power/////////////////////////////////////" + power);
        }
    }


    public void draw(Canvas c) {
        //Matrix m = matrixTranslateAndMove(tankLeft, tankTop + 50, (float) ((-angle) * 180 / Math.PI), tankLeft+GUNBARREL_WIDTH/2, tankTop-GUNBARREL_LENGTH/2);
        angleBarrel = map(angle, 0.050f, 3.180f, 90, -90);
        Matrix m = matrixTranslateAndRotate(gunBarrelLeft, gunBarrelTop, angleBarrel, GUNBARREL_WIDTH / 2, GUNBARREL_LENGTH /2);
        Log.d(TAG, "angle/////////////////////////////////////" + angleBarrel);
        c.drawBitmap(gunBarrelImg, m, null);
        c.drawBitmap(tankImg, tankLeft, tankTop, null);
        updateangle();


    }


    float map(float x, float in_min, float in_max, float out_min, float out_max) {
        return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
    }

    public void
    setTarget(int x, int y) {

        if (x < shootOriginX) x = (int) shootOriginX;
        if (y > shootOriginY) y = (int) shootOriginY;
        if (x == shootOriginX && y == shootOriginY) x = x + 10;

//////////imp range is from 0.5 to 3.14 rad by formula error in x positions
        final float previousAngle = angle;
//        angle = calculateAngle(x, y);
        // angle = map(editangle,0,2000,0.500f,3.280f);

        if (angle > 3.280f) angle = 3.280f;
        if (angle < 0.500f) angle = 0.500f;
        bulletOrigin = calculateBulletOrigin();

        if (angleChanged(previousAngle, angle)) {
            thread.angleChanged(angle);
        }

    }

    public void
    updateangle() {


//////////imp range is from 0.5 to 3.14 rad by formula error in x positions
        final float previousAngle = angle;
//        angle = calculateAngle(x, y);
        angle = map(editangle, 0, 2000, 3.180f, 0.050f);
        if (editangle > 1000) {
            FunctionalAircraft.leftright_game = -1;
        } else {
            FunctionalAircraft.leftright_game = 1;
        }
        if (angle > 3.180f) angle = 3.180f;
        if (angle < 0.050f) angle = 0.050f;
        bulletOrigin = calculateBulletOrigin();

        if (angleChanged(previousAngle, angle)) {
            thread.angleChanged(angle);
        }

    }

    private Pair<Integer, Integer> calculateBulletOrigin() {
        return new Pair<>((int) (shootOriginX + (Math.cos(angle) * (GUNBARREL_LENGTH/2 ) * scale)),
                (int) (shootOriginY - (Math.sin(angle) * (GUNBARREL_LENGTH/2 ) * scale)));
    }

    private float calculateAngle(int x, int y) {
        return Math.abs((float) Math.atan((y - shootOriginY) / (x - shootOriginX)));
    }

    private boolean angleChanged(float before, float after) {
        return 0 < Math.abs((int) ((before - after) * 180 / Math.PI));

    }

    /**
     * called when the user press the screen. It starts the powering addNewEvent
     */
    public void initFiring() {
        tankStatus = STATUS_POWERING;
        power = 10;
        milisecondsPowering = 0;
    }

    public void powercontrol(int value) {
        tankStatus = STATUS_POWERING;
        int x = (int) map(angle, 0.0056f, 3.28f, -50, 50);
        if (x < 0) {
            x = (-x);
        }
        power = value - x;

        milisecondsPowering = 0;
    }

    /**
     * called when the user release the finger and the shoot is performed
     */
    public void doFire() {
        thread.shootBullet(angle, 10 + power * 60 / 100, bulletOrigin);//40 + power * 60 / 100
//        Log.d(TAG, "xpowerx/////////////////////////////////////" + 10 + power * 60 / 100);
//        Log.d(TAG, "power/////////////////////////////////////" + power);
        lastBulletPower = power;
        tankStatus = STATUS_IDLE;
        power = 0;

    }

    /**
     * gives information about the power of the tank
     */
    public int getPower() {
        return power;
    }

    /**
     * gives information about the angle of the gun barrel
     */
    public float getAngle() {
        return angle;
    }

    /**
     * used to show the power of the last shoot
     *
     * @return the power value of the last shoot
     */
    public int getLastBulletPower() {
        return lastBulletPower;
    }


}
