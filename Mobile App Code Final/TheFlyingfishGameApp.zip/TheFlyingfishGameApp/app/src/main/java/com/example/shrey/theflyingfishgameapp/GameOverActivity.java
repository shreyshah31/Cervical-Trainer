package com.example.shrey.theflyingfishgameapp;

/*
     Project Name:      Cervical Trainer
     Author List:       Abhishek Kansara, Shrey Shah
     Filename:          TheFlyingfishGameApp->GameOverActivity

     Working:         This activity will pop up after each game is complete and will ask for play again

                      it also prints score for better understanding to the patients.
                      score transferred from one to another intent using putExtra Function.
*/

import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class GameOverActivity extends AppCompatActivity {
    public BluetoothSocket socket=BluetoothActivity.socket;
    private Button startGame;
    private TextView Score;
    private String str;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);

        str=getIntent().getExtras().get("score").toString();

        startGame=(Button) findViewById(R.id.ply_again_btn);
        Score=(TextView)findViewById(R.id.displayScore);

        startGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent playagain = new Intent(GameOverActivity.this,GameMode.class);
                startActivity(playagain);

            }
        });
        Score.setText("SCORE "+str);
    }
}
