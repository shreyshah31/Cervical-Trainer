package com.example.shrey.theflyingfishgameapp.shoottheflakup;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.shrey.theflyingfishgameapp.BluetoothActivity;
import com.example.shrey.theflyingfishgameapp.GameOverActivity;
import com.example.shrey.theflyingfishgameapp.GameSetting;
import com.example.shrey.theflyingfishgameapp.R;
import com.example.shrey.theflyingfishgameapp.SplashActivity;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

//import com.example.shrey.theflyingfishgameapp.shoottheflakup.App;
//import com.example.shrey.theflyingfishgameapp.shoottheflakup.BrickGame.game.GameBrick;
//import com.example.shrey.theflyingfishgameapp.shoottheflakup.BrickGame.game.TouchSurfaceView;
//import com.example.shrey.theflyingfishgameapp.shoottheflakup.GameReportActivity;
//import com.example.shrey.theflyingfishgameapp.shoottheflakup.GamesSetting;
//import com.example.shrey.theflyingfishgameapp.shoottheflakup.MainActivity;
//import com.example.shrey.theflyingfishgameapp.shoottheflakup.R;
//import com.example.shrey.theflyingfishgameapp.shoottheflakup.Tables.Scores;
//import com.example.shrey.theflyingfishgameapp.shoottheflakup.TrainingActivity;
//import com.sdsmdg.tastytoast.TastyToast;
//import co.lujun.lmbluetoothsdk.BluetoothController;
//import co.lujun.lmbluetoothsdk.base.BluetoothListener;
//import co.lujun.lmbluetoothsdk.base.State;

public class ShootingGameActivity extends Activity {


    //    //
//    private final String DEVICE_ADDRESS = "98:D3:51:F5:E4:A0";// 00:18:E4:40:00:06-roborehab ka hai //98:D3:51:F5:E4:A0-yeh wala mere bluetooth ka hai
//    private final UUID PORT_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");//Serial Port Service ID
//    private InputStream inputStream;
//    private OutputStream outputStream;
//    boolean deviceConnected;
//    private int ekkbaar = 0;
//    byte buffer[];
//    private BluetoothDevice device;
//    boolean stopThread;
//    private String stringnewd;
//    private String datad;
    private int vald = 0, valdy = 0;
    private String thodd;
    private String thoddy;
    //    private int once, xprint;
//    private int datamila = 0;
//    String laststr;
//    private int o = 0;
    private int slen = 0;
    //    int z = 0;
//    String stringd;
//    String thodd1;
//    private int range = 3;
//    private int x2 = 0;
//    Thread workerThread;
//    byte[] readBuffer;
//    int readBufferPosition;
//    volatile boolean stopWorker;
//    public BluetoothSocket socket = BluetoothActivity.socket;
    String thodr;
    int valdr = 0;
//    //

//    //start
//    private BluetoothController mBluetoothController = MainActivity.mBluetoothController;
//    private String rxdata = "";
//    private String posdata;
//    private boolean actionFlag = false, startFlag = false, dataflag, isEnded = false, milestone = true;
//    private Handler handler = new Handler();
//    private Handler mHandler;
//    private Timer timer = new Timer();
//    CountDownTimer cTimer = null;
//    //Filter
//    int emaS = 0;
//    float emaAlpha = 0.4f;
//    //Position
//    private int newAngle,position,offSet,prevPos,angle, maxAngleL = 180, maxAngleR = 180, maxAngle = 180, minval = 320, maxval = 680;
//    public static int locationCarSprite,maxXOnScreen = 700 , minXOnScreen = 40;
//    private float rangePercent = 1.0f;
//    boolean lbFirstTime=false,prevflag=false,startMoving =false;
//    //End of game parameters
//    private int maxGameAngleL =0, maxGameAngleR =0;
//    private double maxGameStrength=0.0;
//    public static String stringMaxAngleL = "maxAngleL", stringMaxAngleR = "maxAngleR", stringMaxStrength = "maxStrength", stringMaxScore = "maxScore";
//    boolean gameEnded = true;
//    double strengthNm =0.0;
//    int strengthVal = 0, initialStrengthVal=0;


    public static int mscreenheight;
    public static int mscreenwidth;
    public static float editangle;
    //     Scores mScores;
    private GameThread game;
    private InputController inputController;
    private Timer timergame1;
    private Handler handlergame;
    int liTime = GameSetting.timesetting;
    CountDownTimer cTimer = null;
    private int n = 0;
    long llSeconds;
    int liMin;
    public static int gamescore;
    private TextView score;
//    Button btnMinus, btnPlus,btnPause;

//    private String GAME_NAME = "Bounce";
//    private BluetoothController mBluetoothController = MainActivity.mBluetoothController;
//    private String rxdata = "";
//    private String posdata;
//    private boolean actionFlag = false, startFlag = false, dataflag, isEnded = false, milestone = true;
//    private Handler handler = new Handler();
//    private TouchSurfaceView mTouchSurfaceView;
//    private Handler mHandler;
//    private TextView mScoreTextView;
//    private TextView mScoreMultiplierTextView;
//    private TextView mLivesTextView;
//    private TextView mHighScoreTextView;
//    private TextView mReadyTextView;
//    private SharedPreferences mSharedPrefs;
//
//
//
//    private SharedPreferences.Editor mSharedPrefsEditor;
//    private long mHighScore;
//    private boolean mNewHighScore;
//    private boolean mFinish;
//    private SoundPool mSoundPool;
//    private HashMap<String, Integer> mSoundIds;
//    private View mDecorView;
//    private TextView tvScore,tvSpeed,tvTime;
//    private Button btnSlow, btnSlowPressed, btnMedium, btnMediumPressed, btnFast, btnFastPressed;
//    Button btnTimeMinus, btnTimePlus;
//    Button btnMinus, btnPlus,btnPause;
//    private ImageView ivIntro;
//    TextView tvStrengthValue;
//    double strengthNm =0.0;
//    private int maxGameAngleL =0, maxGameAngleR =0;
//    int emaS = 0;
//    float emaAlpha = 0.4f;
//    private double maxGameStrength=0.0;
//    public static int level;
//    public Timer timer = new Timer();
//    boolean gameEnded = true;
//    private float rangePercent = 1.0f;
//    boolean lbFirstTime=false,prevflag=false,startMoving =false;
//    private int newAngle,position,offSet,prevPos,angle, maxAngleL = 180,
//            maxAngleR = 180, maxAngle = 180, minval = 320, maxval = 680;
//    private float paddleLimitl = 100;
//    private float paddleLimitr = 1180;
//    private float paddleLimit = 1.3f;
//    public static float paddleLocation;
//    int leftX,rightX;
//    //	private int position = 400, prevPos, prevtubX, range, maxX, minX,maxAngleL = 180, maxAngleR = 180, maxAngle = 180, minval = 320, maxval = 680;
//    int strengthVal = 0, initialStrengthVal=0;
//    int  score = 0;
//    int liTime = 5;
//    CountDownTimer cTimer = null;
//    public long currentcounttime,pausecounttimmer;
//    public static String stringMaxAngleL = "maxAngleL", stringMaxAngleR = "maxAngleR", stringMaxStrength = "maxStrength", stringMaxScore = "maxScore";
//    int time,speed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //requestWindowFeature(Window.FEATURE_NO_TITLE);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        mscreenheight = displayMetrics.heightPixels + getNavigationBarHeight();
        mscreenwidth = displayMetrics.widthPixels;
        setContentView(R.layout.activity_shooting);

        final DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        GameView gameView = findViewById(R.id.game);
        score =findViewById(R.id.tvscore);
        game = new GameThread(this, gameView, metrics);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        // Set the content to appear under the system bars so that the
                        // content doesn't resize when the system bars hide and show.
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // Hide the nav bar and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);

//        mBluetoothController.write("g\ng\n".getBytes());
//        mBluetoothController.write(("a" + (strengthVal + 300)).getBytes());
//        mBluetoothController.write(("a" + (strengthVal + 300)).getBytes());
//        lbFirstTime = true;
//        prevflag = true;
//        tvScore = findViewById(R.id.tvScore);
//        tvSpeed = findViewById(R.id.tvSpeed);
//        tvTime = findViewById(R.id.tvTime);//Text Views
//        btnPause = findViewById(R.id.btnPause);
//        mScores = new Scores(this);
//
//        //start
//        maxAngleL = getIntent().getIntExtra(TrainingActivity.LEFT_RANGE, maxAngleL);
//        maxAngleR = getIntent().getIntExtra(TrainingActivity.RIGHT_RANGE, maxAngleR);
//        strengthVal = getIntent().getIntExtra(TrainingActivity.STRENGTH, strengthVal);
//        time = getIntent().getIntExtra(GamesSetting.GAME_TIME,time);
//        speed = getIntent().getIntExtra(GamesSetting.GAME_SPEED, speed);
//        btnPause = findViewById(R.id.btnPause);
//        initialStrengthVal = strengthVal;
//        strengthNm = 0.012132*strengthVal;
//        strengthNm = 0.012132*strengthVal;
//
//        //Initialise Text Views
//        //tvScore.setText(Integer.toString(0));
//        //tvStrengthValue.setText(String.format("%.2f", strengthNm)+ " Nm");
//        mBluetoothController.write(("a" + (strengthVal + 300)).getBytes());
//        //Initialise Bluetooth
//        init();
//        //end
//        currentcounttime = (liTime * 60 * 1000);
//        setTimeLength();
//        cTimer.start();
//        mBluetoothController.write("g\ng\n".getBytes());
//        mBluetoothController.write(("a" + (strengthVal + 300)).getBytes());
//        mBluetoothController.write(("a" + (strengthVal + 300)).getBytes());
//        lbFirstTime = true;
//        prevflag = true;
//        btnPause.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v)
//            {
//                if(game.shootinggameispaused==true)//
//                {
//                    setTimeLength();
//                    cTimer.start();
//                    game.shootinggameispaused=false;
//                }
//                else{
//
//                    cTimer.cancel();
//                    game.shootinggameispaused=true;
//                }
//            }
//        });
//        if(speed==0){ FunctionalAircraft.TIME_FLYING=10;
//        GameThread.counter=5;
//        AircraftsControl.newaircraftcounter=6000;}
//        else if(speed==1){FunctionalAircraft.TIME_FLYING=5;
//            GameThread.counter=10;
//            AircraftsControl.newaircraftcounter=5000;}
//        else{
        FunctionalAircraft.TIME_FLYING = 3;
        GameThread.counter = 15;
        AircraftsControl.newaircraftcounter = 4000;
        setTimeLength();
//        setUiEnabled(true);
//        }
    }


    private int getNavigationBarHeight() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            DisplayMetrics metrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(metrics);
            int usableHeight = metrics.heightPixels;
            getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
            int realHeight = metrics.heightPixels;
            if (realHeight > usableHeight)
                return realHeight - usableHeight;
            else
                return 0;
        }
        return 0;
    }

    @Override
    protected void onResume() {
        super.onResume();
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        score.setText(String.format("            Timer%02d: %02d                 Score: %04d ",liMin,llSeconds, gamescore));
                        dataupdate();
                    }
                });

            }
        }, 0, 3);

//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        dataupdate();
//                    }
//                });
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        game.inputEvent(event);
        return true;
    }

    @Override
    protected void onStop() {
        super.onStop();
//        mBluetoothController.write("z\n".getBytes());
        game.setRunning(false);
    }

//    public void setTimeLength() {
//        final MediaPlayer sound  =  MediaPlayer.create(this, R.raw.applause);
//        cTimer = new CountDownTimer(currentcounttime, 1000) {
//            public void onTick(long millisUntilFinished) {
//                currentcounttime = millisUntilFinished;
//                long llMillis = millisUntilFinished / 1000;
//                long llSeconds = llMillis % 60;
//                int liMin = (int) (llMillis / 60.0f);
//                if (llSeconds < 10) {
//                    tvTime.setText(" 0" + liMin + " : 0" + llSeconds);
//                } else {
//                    tvTime.setText(" 0" + liMin + " : " + llSeconds);
//                }
//
//                if (millisUntilFinished < (((liTime * 60 * 1000)*25)/100)) {
//                    rangePercent=1.2f;
//                }
//                else if (millisUntilFinished < (((liTime * 60 * 1000)*75)/100)) {
//                    rangePercent=1.1f;
//                }
//
//
//
//            }
//            public void onFinish() {
//                liTime=5;
//                sound.start();
//                score=  bouncescore;
//                updateScore();
//                GameBrick.Stategame.setGamePaused(true);
//                mBluetoothController.write("z\n".getBytes());
//                new Timer().schedule(new TimerTask() {
//                    @Override
//                    public void run() {
//                        FinishGame();
//                        Intent intent = new Intent(ShootingGameActivity.this, GameReportActivity.class);
//                        intent.putExtra(TrainingActivity.LEFT_RANGE, maxAngleL);
//                        intent.putExtra(TrainingActivity.RIGHT_RANGE, maxAngleR);
//                        intent.putExtra(TrainingActivity.STRENGTH, initialStrengthVal);
//                        intent.putExtra(stringMaxScore, score);
//                        intent.putExtra(stringMaxAngleL, maxGameAngleL);
//                        intent.putExtra(stringMaxAngleR, maxGameAngleR);
//                        maxGameStrength = strengthNm;
//                        intent.putExtra(stringMaxStrength, maxGameStrength);
//                        sound.stop();
//                        sound.release();
//                        startActivity(intent);
//                        // this code will be executed after 2 seconds
//                    }
//                }, 3000);
//
//            }
//        };
//    }
//    private void FinishGame() {
//        if (gameEnded) {
//
//
//            gameEnded = false;
//            if (timer != null) {
//                timer.cancel();
//                timer = null;
//            }
//
//            mBluetoothController.write("z\n".getBytes());
//            if (cTimer != null) {
//                cTimer.cancel();
//            }
//            if (mBluetoothController != null) {
//                mBluetoothController.write("a300".getBytes());
//            }
//        }
//    }
//    public void updateScore() {
//        String lsScore = Long.toString(bouncescore);
//        int liScore =  bouncescore;
//        //Log.v(Constraints.TAG,"//////////////////l///////////////////"+liScore);
//        if (liScore > 0) {
//            ContentValues cv = new ContentValues();
//            cv.put(Scores.SCR_PTID, App.getPatientID());
//            cv.put(Scores.SCR_SESSIONID, App.getSession());
//            cv.put(Scores.SCR_GAME, GAME_NAME);
//            cv.put(Scores.SCR_SCORE, liScore);
//            mScores.updateData(cv);
//        }
//    }

    //start

    float map(float x, float in_min, float in_max, float out_min, float out_max) {
        return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
    }

//    private void init() {
//        mBluetoothController.setBluetoothListener(new BluetoothListener() {
//            @Override
//            public void onActionStateChanged(int preState, int state) {
//            }
//
//            @Override
//            public void onActionDiscoveryStateChanged(String discoveryState) {
//            }
//
//            @Override
//            public void onActionScanModeChanged(int preScanMode, int scanMode) {
//            }
//
//            @Override
//            public void onBluetoothServiceStateChanged(final int state) {
//                // If you want to update UI, please run this on UI thread
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        mConnectState = state;
//                        if (mConnectState != State.STATE_CONNECTED) {
//                            TastyToast.makeText(ShootingGameActivity.this, "Bluetooth Connection Lost", TastyToast.LENGTH_LONG, TastyToast.ERROR).show();
//                            mConnectState = State.STATE_DISCONNECTED;
//                            finish();
//                        }
//                    }
//                });
//            }
//
//            @Override
//            public void onActionDeviceFound(BluetoothDevice device, short rssi) {
//            }
//
//            @Override
//            public void onReadData(final BluetoothDevice device, final byte[] data) {
//                // If you want to update UI, please run this on UI thread
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//
//                        rxdata = rxdata + new String(data);
////                        Toast.makeText(ShootingGameActivity.this, rxdata, Toast.LENGTH_SHORT).show();
//                        if (!actionFlag && rxdata.contains("g")) {
//
//                            actionFlag = true;
//                            //ivIntro.setVisibility(View.GONE);
//                            startFlag = true;
//                            timer.schedule(new TimerTask() {
//                                @Override
//                                public void run() {
//                                    handler.post(new Runnable() {
//                                        @Override
//                                        public void run() {
//
//                                            changePos();
//                                        }
//                                    });
//                                }
//                            }, 0, 20);
//                        } else if (rxdata.contains("\n") && actionFlag) {
//                            try {
//                                posdata = rxdata.substring(rxdata.lastIndexOf('\n') - 3, rxdata.lastIndexOf('\n'));
//                                mBluetoothController.write("w\n".getBytes());
//                                dataflag = true;
//                            } catch (Exception e) {
//                            }
//                        }
//                    }
//                });
//            }
//        });
//    }
//    private void init_ema(int raw_val)    {
//        emaS = raw_val;
//    }
//    int get_ema(int raw_val){
//        float x;
//        x = (emaAlpha*raw_val) + ((1-emaAlpha)*emaS); //after * by float result is float
//        emaS = (int)x;
//        return emaS;
//    }
//    public void changePos() {
//        //Log.d("Score Global", Integer.toString(score));
//        if (dataflag && posdata.length() == 3) {
//            try {
//                if (lbFirstTime) {
//                    position = Integer.parseInt(posdata);
//                    offSet = position - 500;
//                    init_ema(newAngle);
//                    lbFirstTime = false;
//                }
//                if (prevflag) {
//                    prevPos = position;
//                    angle = (int) map(position, minval, maxval, -maxAngle, maxAngle) - offSet;
//                    prevflag = false;
//                    startMoving = true;
//                }
//                if (startMoving) {
//                    position = Integer.parseInt(posdata);
//
//                    if (abs(position - prevPos) > 0) {
//                        angle = (int) map(position, minval, maxval, -maxAngle, maxAngle) - offSet;
//                        prevPos = position;
//                    }
//                    if (abs(angle) > 180) {
//                        if (offSet > 0) {
//                            newAngle = 180 - (abs(angle) % 180);
//                        } else {
//                            newAngle = -180 + (abs(angle) % 180);
//                        }
//                    } else {
//                        newAngle = angle;
//                    }
//                    if (abs(newAngle) > 175) {
//                        newAngle = newAngle;
//                        emaS = newAngle;
//                    } else {
//                        newAngle = get_ema(newAngle);
//                    }
//                    if (newAngle <= 0 && newAngle < maxGameAngleL) {
//                        maxGameAngleL = newAngle;
//                    }
//                    if (newAngle >= 0 && newAngle > maxGameAngleR) {
//                        maxGameAngleR = newAngle;
//                    }
//                    editangle =map(newAngle, -maxAngleL * rangePercent, maxAngleR * rangePercent, 0,2000 );
//                    //doodlevx =  map(newAngle, -maxAngleL * rangePercent, maxAngleR * rangePercent, -paddleLimit,paddleLimit );
//                    //doodlevx = publicLimit(doodlevx,paddleLimit,-paddleLimit);
//                    Log.d("newangle",Integer.toString(newAngle));
//                    //   tvRomDebug.setVisibility(View.VISIBLE);
//                    //   tvRomDebug.setText(doodlevx +" "+ maxAngleR*rangePercent+" " + maxAngleL*rangePercent);
//                    score= InfoText.getData();
//                    tvScore.setText(String.format("%04d",score));
//                }
//            } catch (Exception e) {
//
//            }
//            dataflag = false;
//        }
//    }
//    public float publicLimit(float x, float max, float min)
//    {
//        float newX =0.0f;
//        if(x<=min)
//        {
//            newX = min;
//        }
//        else if (x>=max)
//        {
//            newX = max;
//        }
//        else{
//            newX = x;
//        }
//        return newX;
//    }
//    //end


    //
    long map(long x, long in_min, long in_max, long out_min, long out_max) {
        return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
    }

    //
//// IDDHAR SE BLUETOOTH CHALU HOTA HAI
//
//    public void setUiEnabled(boolean bool) {
//        if (ekkbaar == 0) {
//            Start();
//        }
//
//    }
//
//
//    public boolean BTinit() {
//        boolean found = false;
//        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
//        if (bluetoothAdapter == null) {
//            Toast.makeText(ShootingGameActivity.this,"Device doesnt Support Bluetooth",Toast.LENGTH_SHORT).show();
//        }
//        if (!bluetoothAdapter.isEnabled()) {
//            Intent enableAdapter = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
//
//            try {
//                Thread.sleep(1000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//
//
//        Set<BluetoothDevice> bondedDevices = bluetoothAdapter.getBondedDevices();
//        if (bondedDevices.isEmpty()) {
//            Toast.makeText(ShootingGameActivity.this,"Please Pair the Device first",Toast.LENGTH_SHORT).show();
//        } else {
//            for (BluetoothDevice iterator : bondedDevices) {
//                if (iterator.getAddress().equals(DEVICE_ADDRESS)) {
//                    device = iterator;
//                    found = true;
//                    break;
//                }
//            }
//        }
//        return found;
//    }
//
//
//    public boolean BTconnect() {
//        boolean connected = true;
//        try {
//            socket = device.createRfcommSocketToServiceRecord(PORT_UUID);
//            socket.connect();
//        } catch (IOException e) {
//            e.printStackTrace();
//            connected = false;
//        }
//        if (connected) {
//            try {
//                outputStream = socket.getOutputStream();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            try {
//                inputStream = socket.getInputStream();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//        return connected;
//    }
//
//
//    public void Start() {
//        if (BTinit()) {
//            if (BTconnect()) {
//                ekkbaar = 1;
//                setUiEnabled(true);
//                deviceConnected = true;
//                beginListenForData();
//                Toast.makeText(ShootingGameActivity.this,"COnnection Opened \n",Toast.LENGTH_SHORT).show();
//            }
//        }
//    }
//
//
//    void beginListenForData() {
//
////        final Handler handler = new Handler();
////        stopThread = false;
////        buffer = new byte[1024];
////        Thread thread  = new Thread(new Runnable()
////
////        {
////
////            public void run()
////
////            {
////                while(!Thread.currentThread().isInterrupted() && !stopThread)
////                {
////                    try
////                    {
////                        int byteCount = inputStream.available();
////                        if(byteCount > 0)
////                        {
////                            byte[] rawBytes = new byte[byteCount];
////                            inputStream.read(rawBytes);
////                            stringd=new String(rawBytes,"UTF-8");
////                            stringnewd=stringd;
////                            handler.post(new Runnable()
////                            {
////
////                                public void run()
////
////                                {
////                                }
////
////                            });
////                        }
////                    }
////                    catch (IOException ex)
////                    {
////                        stopThread = true;
////                    }
////                }
////
////            }
////        });
////        thread.start();
//        try {
//            final Handler handler = new Handler();
//
//            // this is the ASCII code for a newline character
//            final byte delimiter = 10;
//
//            stopWorker = false;
//            readBufferPosition = 0;
//            readBuffer = new byte[1024];
//
//            workerThread = new Thread(new Runnable() {
//                public void run() {
//
//                    while (!Thread.currentThread().isInterrupted() && !stopWorker) {
//
//                        try {
//
//                            int bytesAvailable = inputStream.available();
//
//                            if (bytesAvailable > 0) {
//
//                                byte[] packetBytes = new byte[bytesAvailable];
//                                inputStream.read(packetBytes);
//
//                                for (int i = 0; i < bytesAvailable; i++) {
//
//                                    byte b = packetBytes[i];
//                                    if (b == delimiter) {
//
//                                        byte[] encodedBytes = new byte[readBufferPosition];
//                                        System.arraycopy(
//                                                readBuffer, 0,
//                                                encodedBytes, 0,
//                                                encodedBytes.length
//                                        );
//
//                                        // specify US-ASCII encoding
//                                        final String data = new String(encodedBytes, "US-ASCII");
//                                        readBufferPosition = 0;
//
//                                        // tell the user data were sent to bluetooth printer device
//                                        handler.post(new Runnable() {
//                                            public void run() {
//                                                stringd = data;
//                                                //Log.d(TAG, "inputstream:" + data);
//                                                //myLabel.setText(data);
//                                                dataupdate();
//                                            }
//                                        });
//
//                                    } else {
//                                        readBuffer[readBufferPosition++] = b;
//                                    }
//                                }
//                            }
//
//                        } catch (IOException ex) {
//                            stopWorker = true;
//                        }
//
//                    }
//                }
//            });
//
//            workerThread.start();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//
//    }
//
//    public void datasend(String s1) {
//        String string = s1;
//        //string.concat("\n");
//        try {
//            outputStream.write(string.getBytes());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//
//    public void ConClose() throws IOException {
//
//        stopThread = true;
//        outputStream.close();
//        inputStream.close();
//        socket.close();
//        setUiEnabled(false);
//        deviceConnected = false;
//    }
//    //
//
    public void dataupdate() {
        String datad = SplashActivity.bluetoothvalues_x_y_z;

        try {
            slen = datad.length();
        } catch (Exception e) {
            e.printStackTrace();
        }

//            data1();
//            data2();
//            data3();

        try {
                  /*  int index1 = datad.indexOf("z");
                    int index2 = datad.indexOf("s");
                    thodd = datad.substring(index1, index2);
                     int slen1=thodd.length();
                     thodd1=thodd.substring(1,slen1);
                     */
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            // vald=Integer.parseInt(thodd1);


            if (datad == "y") {

            } else {
                if (slen >= 3) {
                    int index1 = datad.indexOf("y");
                    thodd = datad.substring(index1 - 3, index1);
                    vald = Integer.parseInt(thodd);
                    vald = vald - 360;


                }
            }


            if (datad == "p") {

            } else {
                if (slen >= 3) {
                    int index11 = datad.indexOf("p");
                    thoddy = datad.substring(index11 - 3, index11);
                    valdy = Integer.parseInt(thoddy);
                    valdy = valdy - 360;
                }
            }


            if (datad == "r") {

            } else {
                if (slen >= 3) {
                    int index12 = datad.indexOf("r");
                    thodr = datad.substring(index12 - 3, index12);
                    valdr = Integer.parseInt(thodr);
                    valdr = valdr - 360;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        editangle = map(valdy, 90, 270, 2000, 0);
        //locationCarSprite = (int) map(vald, 90, 270, minXOnScreen, maxXOnScreen);

    }

    public void setTimeLength() {
        cTimer = new CountDownTimer((liTime * 60 * 1000), 1000) {
            public void onTick(long millisUntilFinished) {
                long llMillis = millisUntilFinished / 1000;
                llSeconds = llMillis % 60;
                liMin = (int) (llMillis / 60.0f);
            }

            public void onFinish() {
                new Timer().schedule(new TimerTask() {
                    @Override
                    public void run() {

                        Intent GameOver = new Intent(ShootingGameActivity.this, GameOverActivity.class);
                        GameOver.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        GameOver.putExtra("score", gamescore);
                        startActivity(GameOver);
                    }
                }, 3000);
            }
        }.start();
    }
}

