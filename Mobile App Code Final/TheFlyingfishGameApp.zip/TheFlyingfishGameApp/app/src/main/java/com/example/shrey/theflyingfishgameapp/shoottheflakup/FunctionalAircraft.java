package com.example.shrey.theflyingfishgameapp.shoottheflakup;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.DisplayMetrics;
import android.util.Log;

import com.example.shrey.theflyingfishgameapp.R;

import java.util.Random;

import static android.content.ContentValues.TAG;

public class FunctionalAircraft extends GraphicComponent {

    private static final int STATUS_FLYING = 0;
    private static final int STATUS_BOOM = 1;
    private static final int STATUS_OVER = 2;

    private static final float AIRCRAFT_WIDTH = (float) (ShootingGameActivity.mscreenwidth/11);
    private static final float AIRCRAFT_HEIGHT = (float) (ShootingGameActivity.mscreenheight/7);

    public static float TIME_FLYING = 5;
    private static final long TIME_EXPLODING = 800;

    private static Bitmap aircraftImg1;
    private static Bitmap aircraftImg2;
    private static Bitmap aircraftImg3;
    private static Bitmap aircraftDownImg;
    private Bitmap currentImg;
    private long timeFlying;
    public static int leftright_game;

    private int status;
    private float posX;
    private float posY;
    private double iniSpeedX;
    private double iniSpeedY;
    private float initPointX;
    private float posY0;
    private Paint linepaint;
    private float drawX;
    private float drawY;
    double random = Math.random();
    private int angle;

    private int leftOrRight;
    private float acceleration;

    private long explodingTimer;

    public FunctionalAircraft(Resources res, DisplayMetrics metrics) {
        super(res, metrics);

        timeFlying = 0;
        angle = 0;
        status = STATUS_FLYING;
        initValues(metrics);
            aircraftImg1 = initBitmap(aircraftImg1, R.drawable.spid1, AIRCRAFT_WIDTH, AIRCRAFT_HEIGHT);
            aircraftImg2 = initBitmap(aircraftImg2, R.drawable.spid3, AIRCRAFT_WIDTH, AIRCRAFT_HEIGHT);
            aircraftImg3 = initBitmap(aircraftImg3, R.drawable.spid4, AIRCRAFT_WIDTH, AIRCRAFT_HEIGHT);
            aircraftDownImg = initBitmap(aircraftDownImg, R.drawable.spid2, AIRCRAFT_WIDTH, AIRCRAFT_HEIGHT);

        if (random<=0.3f) { currentImg = aircraftImg1; }
        else if (random>=0.7f) {currentImg = aircraftImg2; }
        else if (random<=0.7f&&random>=0.3f) {currentImg = aircraftImg3; }
        linepaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        linepaint.setColor(Color.BLACK);
        linepaint.setStrokeWidth(2);

    }

    private void initValues(DisplayMetrics metrics) {
        //random values
        leftOrRight = (Math.random() < 0.5 ? 1 : -1);
        Random r = new Random();
        initPointX= r.nextInt(ShootingGameActivity.mscreenwidth-(int)AIRCRAFT_WIDTH);
        int lowerPosition = (int)(ShootingGameActivity.mscreenheight*1.5f);
        acceleration = (float) (lowerPosition / Math.pow(TIME_FLYING / 2, 2));
        iniSpeedX = (metrics.widthPixels / TIME_FLYING);
        iniSpeedY = (TIME_FLYING * acceleration / 2) - 1 / TIME_FLYING;

        Log.d(TAG, "width/////////////////////////////////////" + metrics.widthPixels);
    }

    public void draw(Canvas c) {
        Matrix m = matrixTranslateAndMove(drawX, drawY, angle, posX, posY);
        c.drawBitmap(currentImg, m, null);
        if (status == STATUS_FLYING) {
            //hard
            c.drawLine(drawX + (AIRCRAFT_WIDTH/2), 0, drawX + (AIRCRAFT_WIDTH/2), drawY + 20, linepaint);
        }
    }


    public void update(long elapsedTime) {
        if (status == STATUS_FLYING) {
            handleFlying(elapsedTime);
        } else if (status == STATUS_BOOM) {
            handleExploded(elapsedTime);
        }
        drawX = (float) (posX - (AIRCRAFT_WIDTH * 0.375) * scale);
        Log.d(TAG, "xxxx/////////////////////////////////////" + drawX);
        drawY = posY - (AIRCRAFT_HEIGHT / 2) * scale;
    }

    private void handleFlying(long elapsedTime) {
        timeFlying += elapsedTime;
        explodingTimer += elapsedTime;
        double t2 = (double) (explodingTimer) / 1000;
        double timeFlyingSeconds = (double) (timeFlying) / 1000;
        float x = (float) (1280 * Math.random());
        posX = (float) (initPointX);//(float) (initPointX +  iniSpeedX*timeFlyingSeconds* leftOrRight);
        posY = (float) (iniSpeedY * timeFlyingSeconds - (acceleration / 2 * Math.pow(timeFlyingSeconds, 2)));
        //angle = (leftOrRight >0?180:0)+   (int) (Math.atan((iniSpeedY-acceleration*timeFlyingSeconds)/iniSpeedX* leftOrRight)*180/ Math.PI);
        if (posY < 0) status = STATUS_OVER;

    }

    private void handleExploded(long elapsedTime) {
        explodingTimer += elapsedTime;
        double t2 = (double) (explodingTimer) / 1000;
        //posX = (float) (initPointX +  iniSpeedX*t2* leftOrRight);
        posY = (float) (posY0 + iniSpeedY * t2 + (7.0 / 2 * Math.pow(t2, 2)));
        if (explodingTimer > TIME_EXPLODING)
            status = STATUS_OVER;
    }

    public boolean isOver() {
        return (status == STATUS_OVER);
    }

    public void setImpact() {
        status = STATUS_BOOM;
        currentImg = aircraftDownImg;
        explodingTimer = 0;
        initPointX = posX;
        posY0 = posY;
        iniSpeedY = iniSpeedY - (acceleration * explodingTimer / 1000);
    }

    public boolean impactDetected(FunctionalBullet b) {
        boolean impact = false;
        float diffX = Math.abs(posX - b.getPosX());
        float diffY = Math.abs(posY - b.getPosY());
        if (diffX < 50 && diffY < 50 * scale) {
            impact = true;
        } else impact = false;
        return impact;
    }

    public boolean isFlying() {
        return (status == STATUS_FLYING);
    }
}



