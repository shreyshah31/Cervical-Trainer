package com.example.shrey.theflyingfishgameapp;


/*
     Project Name:      Cervical Trainer
     Author List:       Abhishek Kansara, Shrey Shah
     Filename:          TheFlyingfishGameApp->GameSetting

     Working:         This activity will pop up before every game there are three criterias which needs to filled before the
                      patient starts the game
                      1) Range -range of motion inside game
                      2) Time - timer for playing the game
                      3) Difficulty - how fast the movement can be used

                      This values are set inside this activity by plus and minus button of each attribute.
                      and is send to next game activity by using intent and putExtra functions.

*/


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.shrey.theflyingfishgameapp.shoottheflakup.ShootingGameActivity;
import com.google.android.material.button.MaterialButton;

public class GameSetting extends BaseActivity {

    Button rangeplus,rangeminus,timeplus,timeminus,diffplus,diffminus,start;
    public static int rangesetting=20,timesetting=2,diffsetting=1;
    private int gameNumber;
    TextView rangevalue,timevalue,diffvalue;
    String strrange,strtime,strdiff,gameNumberStr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_setting);

        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        // Set the content to appear under the system bars so that the
                        // content doesn't resize when the system bars hide and show.
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // Hide the nav bar and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);

        rangeplus=findViewById(R.id.rangebtnplus);
        rangeminus=findViewById(R.id.rangebtnminus);
        timeplus=findViewById(R.id.timebtnplus);
        timeminus=findViewById(R.id.timebtnminus);
        diffplus=findViewById(R.id.diffbtnplus);
        diffminus=findViewById(R.id.diffbtnminus);
        start=findViewById(R.id.start);

        rangevalue=findViewById(R.id.rangevalue1);
        timevalue=findViewById(R.id.timevalue1);
        diffvalue=findViewById(R.id.diffvalue1);

        gameNumberStr=getIntent().getStringExtra("gameNumber");

        gameNumber=Integer.valueOf(gameNumberStr);



        rangeplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rangesetting>=0) {
                    rangesetting = rangesetting + 5;
                    strrange = Integer.toString(rangesetting);
                    rangevalue.setText(strrange + " degrees");
                }
            }
        });

        rangeminus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rangesetting>0) {
                    rangesetting = rangesetting - 5;
                    strrange = Integer.toString(rangesetting);
                    rangevalue.setText(strrange + " degrees");
                }
            }
        });

        timeplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(timesetting>=1) {
                    timesetting++;
                    strtime = Integer.toString(timesetting);
                    timevalue.setText(strtime + " minutes");
                }
            }
        });

        timeminus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(timesetting>1) {
                    timesetting--;
                    strtime = Integer.toString(timesetting);
                    timevalue.setText(strtime + " minutes");
                }
            }
        });

        diffplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(diffsetting>=1) {
                    diffsetting++;
                    strdiff = Integer.toString(diffsetting);
                    diffvalue.setText(strdiff + " level");
                }
            }
        });

        diffminus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(diffsetting>1) {
                    diffsetting--;
                    strdiff = Integer.toString(diffsetting);
                    diffvalue.setText(strdiff + " level");
                }
            }
        });

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(gameNumber==1)
                {
                    Intent intent = new Intent(GameSetting.this,DogAndBoneActivity.class);
                    startActivity(intent);
                }
                if(gameNumber==2)
                {
                    Intent intent = new Intent(GameSetting.this, MainActivity.class);
                    startActivity(intent);
                }
                if(gameNumber==3)
                {
                    Intent intent = new Intent(GameSetting.this, ShootingGameActivity.class);
                    startActivity(intent);
                }

            }
        });
    }
}
