package com.example.shrey.theflyingfishgameapp;

    /*
         Project Name:      Cervical Trainer
         Author List:       Abhishek Kansara,Shrey Shah
         Filename:          TheFlyingfishGameApp->DogAndBoneActivity

         Working:         This particular activity was used for dog and the bone activity
                          this activity has a run handler function which continuously runs the dogandbone java file in it.


    */
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;

import java.util.Timer;
import java.util.TimerTask;

public class DogAndBoneActivity extends AppCompatActivity {

    public BluetoothSocket socket=BluetoothActivity.socket;
    private  dogandboneview dogandbone;
    private Handler handler=new Handler();
    private static long Interval=30;
    private int dogtime,dogdiff,dogrange;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dogandbone = new dogandboneview(this);
        setContentView(dogandbone);

        dogtime=getIntent().getIntExtra("time",dogtime);
        dogrange=getIntent().getIntExtra("range",dogrange);
        dogdiff=getIntent().getIntExtra("diff",dogdiff);



        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        // Set the content to appear under the system bars so that the
                        // content doesn't resize when the system bars hide and show.
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // Hide the nav bar and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);


        Timer timer=new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        dogandbone.invalidate();
                    }
                });
            }
        },0,Interval);
    }

    public int dogTime()
    {
        return dogtime;
    }
    public int dogDiff()
    {
        return dogdiff;
    }
    public int dogRange()
    {
        return dogrange;
    }
}
