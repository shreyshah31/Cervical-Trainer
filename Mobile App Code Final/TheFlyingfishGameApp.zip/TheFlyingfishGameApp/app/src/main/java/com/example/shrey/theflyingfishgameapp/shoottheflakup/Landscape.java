package com.example.shrey.theflyingfishgameapp.shoottheflakup;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.util.DisplayMetrics;

import com.example.shrey.theflyingfishgameapp.R;

class Landscape {
    private Bitmap mBackgroundImage;
    public Landscape(Resources res, DisplayMetrics metrics) {
        mBackgroundImage = BitmapFactory.decodeResource(res, R.drawable.doodlebgimg);
        mBackgroundImage= Bitmap.createScaledBitmap(
                mBackgroundImage, ShootingGameActivity.mscreenwidth, ShootingGameActivity.mscreenheight, true);
    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(mBackgroundImage, 0, 0, null);
    }
}
