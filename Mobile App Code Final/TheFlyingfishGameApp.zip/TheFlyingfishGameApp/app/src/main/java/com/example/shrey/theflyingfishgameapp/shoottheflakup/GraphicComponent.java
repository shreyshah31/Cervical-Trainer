package com.example.shrey.theflyingfishgameapp.shoottheflakup;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.util.DisplayMetrics;

abstract class  GraphicComponent implements Renderable {

    private final Resources res;
    protected final float scale;

    public GraphicComponent(Resources res, DisplayMetrics metrics) {
        this.res = res;
        scale = Utils.scale(metrics);
    }


    protected Bitmap initBitmap(Bitmap image, int resource, float width, float height) {
        if (image == null) {
            image = BitmapFactory.decodeResource(res, resource);
            image = Bitmap.createScaledBitmap(image, (int) (width * scale), (int) (height * scale), true);
        }
        return image;

    }

    protected Bitmap owninitBitmap(Bitmap image, int resource, float width, float height) {
        if (image == null) {
            image = BitmapFactory.decodeResource(res, resource);
            image = getResizedBitmap(image, (int) (width * scale), (int) (height * scale));
        }
        return image;
    }

    public static Bitmap getResizedBitmap(Bitmap bm, int newWidth, int newHeight) {
        int width = bm.getWidth();
        int height = bm.getHeight();
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height;
        // CREATE A MATRIX FOR THE MANIPULATION
        Matrix matrix = new Matrix();
        // RESIZE THE BIT MAP
        matrix.postScale(scaleWidth, scaleHeight);
        // "RECREATE" THE NEW BITMAP
        Bitmap resizedBitmap = Bitmap.createBitmap(bm, 0, 0, width, height, matrix, false);
        bm.recycle();
        return resizedBitmap;
    }


    protected Matrix matrixTranslateAndMove(float transX, float transY, float angle, float pivotX, float pivotY) {
        Matrix m = new Matrix();
        m.postRotate(angle, pivotX, pivotY);
        m.postTranslate(transX, transY);
        return m;
    }
    protected Matrix matrixTranslateAndRotate(float transX, float transY, float angle, float pivotX, float pivotY) {
        Matrix m = new Matrix();
        m.setRotate(angle, pivotX, pivotY);
        m.postTranslate(transX, transY); // Centers image
      //  m.postTranslate(transX, transY);
        return m;
    }





}
