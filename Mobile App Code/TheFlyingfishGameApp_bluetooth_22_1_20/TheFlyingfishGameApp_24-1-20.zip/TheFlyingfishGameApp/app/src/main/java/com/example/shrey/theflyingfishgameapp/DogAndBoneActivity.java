package com.example.shrey.theflyingfishgameapp;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.os.Handler;

import java.util.Timer;
import java.util.TimerTask;

public class DogAndBoneActivity extends AppCompatActivity {

    public BluetoothSocket socket=BluetoothActivity.socket;
    private  dogandboneview dogandbone;
    private Handler handler=new Handler();
    private static long Interval=30;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dogandbone = new dogandboneview(this);
        setContentView(dogandbone);

        Timer timer=new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        dogandbone.invalidate();
                    }
                });
            }
        },0,Interval);
    }
}
