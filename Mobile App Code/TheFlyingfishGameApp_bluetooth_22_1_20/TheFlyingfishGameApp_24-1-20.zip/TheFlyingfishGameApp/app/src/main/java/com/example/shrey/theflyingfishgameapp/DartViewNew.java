package com.example.shrey.theflyingfishgameapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.util.Timer;
import java.util.TimerTask;

public class DartViewNew extends AppCompatActivity {

    private ImageView blue_dart, red_dart;
    private FrameLayout dartframe;
    private Handler handler1;
    private int vald = 0, valdy = 0, valdr = 0;
    private String thodd, thoddy, thodr;
    private int slen = 0;
    private float yaw,pitch,roll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        // Set the content to appear under the system bars so that the
                        // content doesn't resize when the system bars hide and show.
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // Hide the nav bar and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
        setContentView(R.layout.activity_dart_view_new);
        dartframe = findViewById(R.id.dartframe);
        red_dart = findViewById(R.id.red_dart);
        blue_dart = findViewById(R.id.blue_dart);

    }

    @Override
    protected void onResume() {
        super.onResume();
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {

            @Override
            public void run() {
                red_dart.setX((dartframe.getHeight() / 2) - red_dart.getHeight() / 2);
                red_dart.setY((dartframe.getWidth() / 2) - red_dart.getWidth() / 2);
                blue_dart.setX((dartframe.getHeight() / 2) - blue_dart.getHeight() / 2);
                blue_dart.setY((dartframe.getWidth() / 2) - blue_dart.getWidth() / 2);
                dataupdate();
            }
        }, 0, 25);
    }

    float map(float x, float in_min, float in_max, float out_min, float out_max) {
        return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
    }

    public void dataupdate() {
        String datad = SplashActivity.bluetoothvalues_x_y_z;
        try {
            slen = datad.length();
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            if (datad == "y") {
            } else {
                if (slen >= 3) {
                    int index1 = datad.indexOf("y");
                    thodd = datad.substring(index1 - 3, index1);
                    vald = Integer.parseInt(thodd);
                    vald = vald - 360;
                    yaw = map(vald,90,270,0,dartframe.getHeight());
                    red_dart.setX((yaw) - red_dart.getHeight() / 2);
                }
            }
            if (datad == "p") {
            } else {
                if (slen >= 3) {
                    int index11 = datad.indexOf("p");
                    thoddy = datad.substring(index11 - 3, index11);
                    valdy = Integer.parseInt(thoddy);
                    valdy = valdy - 360;

                }
            }
            if (datad == "r") {
            } else {
                if (slen >= 3) {
                    int index12 = datad.indexOf("r");
                    thodr = datad.substring(index12 - 3, index12);
                    valdr = Integer.parseInt(thodr);
                    valdr = valdr - 360;
                    pitch = map(valdr,90,270,0,dartframe.getWidth());
                    red_dart.setY((pitch) - red_dart.getWidth() / 2);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

//        editangle = map(valdy, 90, 270, 2000, 0);
//        //locationCarSprite = (int) map(vald, 90, 270, minXOnScreen, maxXOnScreen);
    }
}
