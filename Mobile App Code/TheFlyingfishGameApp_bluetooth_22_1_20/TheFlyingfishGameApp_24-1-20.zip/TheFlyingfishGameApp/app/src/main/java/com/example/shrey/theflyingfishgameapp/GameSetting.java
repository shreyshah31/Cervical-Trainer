package com.example.shrey.theflyingfishgameapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.shrey.theflyingfishgameapp.shoottheflakup.ShootingGameActivity;
import com.google.android.material.button.MaterialButton;

public class GameSetting extends AppCompatActivity {

    Button rangeplus,rangeminus,timeplus,timeminus,diffplus,diffminus,start;
    private int range=20,time=2,diff=1,gameNumber;
    TextView rangevalue,timevalue,diffvalue;
    String strrange,strtime,strdiff,gameNumberStr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_setting);

        rangeplus=findViewById(R.id.rangebtnplus);
        rangeminus=findViewById(R.id.rangebtnminus);
        timeplus=findViewById(R.id.timebtnplus);
        timeminus=findViewById(R.id.timebtnminus);
        diffplus=findViewById(R.id.diffbtnplus);
        diffminus=findViewById(R.id.diffbtnminus);
        start=findViewById(R.id.start);

        rangevalue=findViewById(R.id.rangevalue1);
        timevalue=findViewById(R.id.timevalue1);
        diffvalue=findViewById(R.id.diffvalue1);

        gameNumberStr=getIntent().getStringExtra("gameNumber");

        gameNumber=Integer.valueOf(gameNumberStr);



        rangeplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(range>=0) {
                    range = range + 5;
                    strrange = Integer.toString(range);
                    rangevalue.setText(strrange + " degrees");
                }
            }
        });

        rangeminus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(range>0) {
                    range = range - 5;
                    strrange = Integer.toString(range);
                    rangevalue.setText(strrange + " degrees");
                }
            }
        });

        timeplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(time>=1) {
                    time++;
                    strtime = Integer.toString(time);
                    timevalue.setText(strtime + " minutes");
                }
            }
        });

        timeminus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(time>1) {
                    time--;
                    strtime = Integer.toString(time);
                    timevalue.setText(strtime + " minutes");
                }
            }
        });

        diffplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(diff>=1) {
                    diff++;
                    strdiff = Integer.toString(diff);
                    diffvalue.setText(strdiff + " level");
                }
            }
        });

        diffminus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(diff>1) {
                    diff--;
                    strdiff = Integer.toString(diff);
                    diffvalue.setText(strdiff + " level");
                }
            }
        });

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(gameNumber==1)
                {
                    Intent intent = new Intent(GameSetting.this,DogAndBoneActivity.class);
                    startActivity(intent);
                }
                if(gameNumber==2)
                {
                    Intent intent = new Intent(GameSetting.this, MainActivity.class);
                    startActivity(intent);
                }
                if(gameNumber==3)
                {
                    Intent intent = new Intent(GameSetting.this, ShootingGameActivity.class);
                    startActivity(intent);
                }

            }
        });
    }
}
