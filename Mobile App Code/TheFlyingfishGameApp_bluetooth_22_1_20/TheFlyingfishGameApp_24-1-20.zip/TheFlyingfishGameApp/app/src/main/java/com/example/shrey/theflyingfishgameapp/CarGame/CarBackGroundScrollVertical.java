package com.example.shrey.theflyingfishgameapp.CarGame;


import android.graphics.Bitmap;
import android.graphics.Canvas;

public class CarBackGroundScrollVertical {

    private Bitmap image;
    private int x=0, y, dy;
    private int imageHeight ;

    public CarBackGroundScrollVertical(Bitmap res)
    {
        image = res;
        imageHeight = res.getHeight();
        y = -(imageHeight-(CarSprite.screenHeight));
    }
    public void update()
    {
      // Log.d("bgHeight", Integer.toString(CarSprite.imageHeight));// 2539
        y+=dy;

    }
    public void draw(Canvas canvas)
    {
        canvas.drawBitmap(image, x, y,null);
        if((y + CarGameView.gameSpeed+4) > -1)
        {
            y = -(imageHeight-CarSprite.screenHeight)+ CarSprite.screenHeight/10;
            canvas.drawBitmap(image,x,y,  null);
        }
    }
    public void setVector(int dy)
    {
        this.dy = dy;
    }
}