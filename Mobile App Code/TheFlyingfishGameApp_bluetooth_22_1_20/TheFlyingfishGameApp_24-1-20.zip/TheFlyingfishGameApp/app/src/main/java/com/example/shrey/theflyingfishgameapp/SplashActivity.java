package com.example.shrey.theflyingfishgameapp;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.shrey.theflyingfishgameapp.shoottheflakup.ShootingGameActivity;
import com.mapzen.speakerbox.Speakerbox;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

public class SplashActivity extends BaseActivity {
    //
    private final String DEVICE_ADDRESS = "00:19:08:35:C5:4F";//98:D3:51:F5:E4:A0"
    // new cervical 00:19:08:35:C5:4F
    private final UUID PORT_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");//Serial Port Service ID
    private InputStream inputStream;
    private OutputStream outputStream;
    boolean deviceConnected;
    private int ekkbaar = 0;
    byte buffer[];
    private BluetoothDevice device;
    boolean stopThread;
//    private String stringnewd;
//    private String datad;
//    private int vald = 0, valdy = 0;
//    private String thodd;
//    private String thoddy;
//    private int once, xprint;
//    private int datamila = 0;
//    String laststr;
//    private int o = 0;
//    private int slen = 0;
//    int z = 0;
    public static String bluetoothvalues_x_y_z;
//    String thodd1;
//    private int range = 3;
//    private int x2 = 0;



    Thread workerThread;
    byte[] readBuffer;
    int readBufferPosition;
    volatile boolean stopWorker;
//
//    private int score, target = 100, level = 0;
//    private float xtarget = 0, ytarget = 0;
//    private int limity = 0, yp, yprint;
//    private int y1 = 0, b1 = 0;
//    private int yaw_bt = 0, roll_bt = 0, pitch_bt = 0;
//    String thodr;
//    int valdr = 0;
    //
    private Button start, dart, analysebut, graph, cargame, shootinggame, bluetoothon, bluetoothoff;
    private TextView text1;

    public BluetoothSocket socket = BluetoothActivity.socket;
    public static databasehelper mDatabaseHelper = DatabaseActivity.mDatabaseHelper;

    private String patient_name, patient_name_replace;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        // Set the content to appear under the system bars so that the
                        // content doesn't resize when the system bars hide and show.
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // Hide the nav bar and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);

        patient_name = getIntent().getStringExtra("patientName");

        start = (Button) findViewById(R.id.startGame);
        bluetoothon = (Button) findViewById(R.id.bluetoothon);
        bluetoothoff = (Button) findViewById(R.id.bluetoothoff);
        dart = (Button) findViewById(R.id.dartGame);
        //analysebut=(Button)findViewById(R.id.analyse);
        text1 = (TextView) findViewById(R.id.textView1);
        graph = (Button) findViewById(R.id.graph);
        // cargame=(Button)findViewById(R.id.cargame);
        // shootinggame=(Button)findViewById(R.id.shootinggame);

        patient_name_replace = patient_name.replace("_", " ");

        text1.setText("Hi, " + patient_name_replace);

        Speakerbox speakerbox = new Speakerbox(getApplication());

        speakerbox.play("hi, how are you"+patient_name_replace);

        mDatabaseHelper.createAnalysisTable(patient_name);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SplashActivity.this, GameMode.class);
                i.putExtra("patientName", patient_name);
                startActivity(i);
            }
        });

        bluetoothoff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setUiEnabled(true);
            }
        });

        bluetoothon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    ConClose();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        dart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent s = new Intent(SplashActivity.this, DartViewNew.class);
                s.putExtra("patientName", patient_name);
                startActivity(s);
            }
        });
      /*  analysebut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(SplashActivity.this,AnalyseActivity.class);
                i.putExtra("patientName", patient_name);
                startActivity(i);
            }
        });

       */
        graph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SplashActivity.this, Graph_Activity.class);
                i.putExtra("patientName", patient_name);
                startActivity(i);
            }
        });
     /*   cargame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(SplashActivity.this,CarGameActivity.class);
                i.putExtra("patientName",patient_name);
                startActivity(i);
            }
        });
        shootinggame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(SplashActivity.this, ShootingGameActivity.class);
                i.putExtra("patientName",patient_name);
                startActivity(i);
            }
        });

      */

       /* Thread thread = new Thread();
        {
                try {
                    sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    Intent mainIntent = new Intent(SplashActivity.this, MainActivity.class);
                    startActivity(mainIntent);
                }

        };
       thread.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();*/
    }


    // IDDHAR SE BLUETOOTH CHALU HOTA HAI

    public void setUiEnabled(boolean bool)
    {
        if(ekkbaar==0) {
            Start();
        }

    }


    public boolean BTinit()
    {
        boolean found=false;
        BluetoothAdapter bluetoothAdapter=BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null)
        {
            Toast.makeText(SplashActivity.this,"Device doesnt Support Bluetooth",Toast.LENGTH_SHORT).show();
        }
        if(!bluetoothAdapter.isEnabled())
        {
            Intent enableAdapter = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);

            try
            {
                Thread.sleep(100);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
        }


        Set<BluetoothDevice> bondedDevices = bluetoothAdapter.getBondedDevices();
        if(bondedDevices.isEmpty())
        {
            Toast.makeText(SplashActivity.this,"Please Pair the Device first",Toast.LENGTH_SHORT).show();
        }
        else
        {
            for (BluetoothDevice iterator : bondedDevices)
            {
                if(iterator.getAddress().equals(DEVICE_ADDRESS))
                {
                    device=iterator;
                    found=true;
                    break;
                }
            }
        }
        return found;
    }



    public boolean BTconnect()
    {
        boolean connected=true;
        try
        {
            socket = device.createRfcommSocketToServiceRecord(PORT_UUID);
            socket.connect();
        }
        catch (IOException e)
        {
            e.printStackTrace();
            connected=false;
        }
        if(connected)
        {
            try
            {
                outputStream=socket.getOutputStream();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
            try
            {
                inputStream=socket.getInputStream();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
        return connected;
    }


    public void Start()
    {
        if(BTinit())
        {
            if(BTconnect())
            {
                ekkbaar=1;
                setUiEnabled(true);
                deviceConnected = true;
                bluetoothoff.setVisibility(View.GONE);
                bluetoothon.setVisibility(View.VISIBLE);
                beginListenForData();
                Toast.makeText(SplashActivity.this,"COnnection Opened \n",Toast.LENGTH_SHORT).show();
            }
        }
    }


    void beginListenForData()
    {

//        final Handler handler = new Handler();
//        stopThread = false;
//        buffer = new byte[1024];
//        Thread thread  = new Thread(new Runnable()
//
//        {
//
//            public void run()
//
//            {
//                while(!Thread.currentThread().isInterrupted() && !stopThread)
//                {
//                    try
//                    {
//                        int byteCount = inputStream.available();
//                        if(byteCount > 0)
//                        {
//                            byte[] rawBytes = new byte[byteCount];
//                            inputStream.read(rawBytes);
//                            stringd=new String(rawBytes,"UTF-8");
//                            stringnewd=stringd;
//                            handler.post(new Runnable()
//                            {
//
//                                public void run()
//
//                                {
//                                }
//
//                            });
//                        }
//                    }
//                    catch (IOException ex)
//                    {
//                        stopThread = true;
//                    }
//                }
//
//            }
//        });
//        thread.start();
        try {
            final Handler handler = new Handler();

            // this is the ASCII code for a newline character
            final byte delimiter = 10;

            stopWorker = false;
            readBufferPosition = 0;
            readBuffer = new byte[1024];

            workerThread = new Thread(new Runnable() {
                public void run() {

                    while (!Thread.currentThread().isInterrupted() && !stopWorker) {

                        try {

                            int bytesAvailable = inputStream.available();

                            if (bytesAvailable > 0) {

                                byte[] packetBytes = new byte[bytesAvailable];
                                inputStream.read(packetBytes);

                                for (int i = 0; i < bytesAvailable; i++) {

                                    byte b = packetBytes[i];
                                    if (b == delimiter) {

                                        byte[] encodedBytes = new byte[readBufferPosition];
                                        System.arraycopy(
                                                readBuffer, 0,
                                                encodedBytes, 0,
                                                encodedBytes.length
                                        );

                                        // specify US-ASCII encoding
                                        final String data = new String(encodedBytes, "US-ASCII");
                                        readBufferPosition = 0;

                                        // tell the user data were sent to bluetooth printer device
                                        handler.post(new Runnable() {
                                            public void run() {
                                                bluetoothvalues_x_y_z=data;

                                                //Log.d(TAG, "inputstream:" + data);
                                                //myLabel.setText(data);
                                            }
                                        });

                                    } else {
                                        readBuffer[readBufferPosition++] = b;
                                    }
                                }
                            }

                        } catch (IOException ex) {
                            stopWorker = true;
                        }

                    }
                }
            });

            workerThread.start();

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    public void datasend(String s1)
    {
        String string=s1;
        //string.concat("\n");
        try
        {
            outputStream.write(string.getBytes());
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
    public void ConClose() throws IOException
    {
        bluetoothon.setVisibility(View.GONE);
        bluetoothoff.setVisibility(View.VISIBLE);
        stopThread = true;
        outputStream.close();
        inputStream.close();
        socket.close();
        setUiEnabled(false);
        deviceConnected=false;
    }
}
