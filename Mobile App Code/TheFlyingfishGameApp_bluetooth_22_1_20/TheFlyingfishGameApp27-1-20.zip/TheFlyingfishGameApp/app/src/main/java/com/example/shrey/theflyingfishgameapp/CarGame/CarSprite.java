package com.example.shrey.theflyingfishgameapp.CarGame;

import android.graphics.Bitmap;
import android.graphics.Canvas;

import com.example.shrey.theflyingfishgameapp.CarGameActivity;

import java.util.Timer;
import java.util.TimerTask;

public class CarSprite {
    public static Bitmap image, tempImage;
    public static int x, y;
    public static boolean doSet = true;
    public static int xVelocity = 2;
    public static int screenWidth;
    public static int screenHeight;


    public CarSprite(Bitmap bmp) {
        image = bmp;
        screenHeight = CarGameActivity.mscreenheight;
        screenWidth = CarGameActivity.maxXOnScreen;
        x = CarGameActivity.mscreenwidth / 2;
        y = CarGameActivity.mscreenheight * 3 / 4;


    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(image, x, y, null);
    }

    public void blink(final Bitmap bmp) {
        tempImage = image;
        image = bmp;
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                image = tempImage;
                new Timer().schedule(new TimerTask() {
                    @Override
                    public void run() {
                        image = bmp;
                        new Timer().schedule(new TimerTask() {
                            @Override
                            public void run() {
                                image = tempImage;
                            }
                        }, 250);
                    }
                }, 250);
            }
        }, 250);
    }

    public void setImage(Bitmap bmp) {
        image = bmp;
    }

    public void update() {
        if (doSet == true) {
            if (CarGameActivity.locationCarSprite < CarGameActivity.maxXOnScreen &&
                    CarGameActivity.locationCarSprite > CarGameActivity.minXOnScreen) {
                x = CarGameActivity.locationCarSprite;
            }

        }
    }
}
