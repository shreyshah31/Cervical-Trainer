package com.example.shrey.theflyingfishgameapp.CarGame;

import android.graphics.Bitmap;
import android.graphics.Canvas;


public class CarObstacleSprite {


    public Bitmap image;
    public int xX, yY, yVelocity;
    public static int curLaneNo;

    public CarObstacleSprite (Bitmap bmp,  int x, int y) {
        image = bmp;
        yY = y;
        xX = x;
    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(image,  xX,  yY, null);
    }
    public void update() {
        yVelocity = CarGameView.gameVelocity;
        yY += yVelocity;

    }

}