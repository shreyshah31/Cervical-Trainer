package com.example.shrey.theflyingfishgameapp.CarGame;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Build;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.annotation.RequiresApi;

import com.example.shrey.theflyingfishgameapp.CarGameActivity;
import com.example.shrey.theflyingfishgameapp.MainActivity;
import com.example.shrey.theflyingfishgameapp.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class CarGameView extends SurfaceView implements SurfaceHolder.Callback {

    private CarGameActivity carGameActivity;
    public static int gameSpeed = 0;
    public static int gameVelocity ;
    public static int gameScore=0;
    public static int musicOn =1;
    public static int musicOff =0;
    private int carWidth;
    private int carHeight ;
    int objectScaleWidth = 12;
    int objectScaleHeight = 5;
    private int coinDiameter = 100;
    private int mpLength = 0;
    private boolean gameStarted = false;
    private int spawnCounter=0;
    private List<Integer> laneNo;
    private List<Integer> DistanceNo;
    private  List<Integer> spawnPosition;

    private int prevLane = 0, prevCollision=0,value1=0,value2=0;

    private CollisionDetect collisionDetect;

    private final CarGameThread thread;

    private CarSprite carSprite;

    private CarBackGroundScrollVertical backGroundScrollVertical;

    private CarObstacleSprite car;
    private CarObstacleSprite other;
    private CarObstacleSprite truck;
    private CarObstacleSprite coin;

    private List<CarObstacleSprite> obstacles;


    public AudioAttributes attrs ;
    public SoundPool sp ;
    public int soundIds[] = new int[10];
    public Context contextLocal;
    public MediaPlayer mp;
    public static boolean gameNotPaused = true;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public CarGameView(Context context)    {
        super(context);
        getHolder().addCallback(this);
        carGameActivity = new CarGameActivity();
        thread = new CarGameThread(getHolder(), this);
        setFocusable(true);

        contextLocal =context;
        InitAudio();
        carWidth =  CarGameActivity.maxXOnScreen / objectScaleWidth;
        carHeight = CarGameActivity.mscreenheight / objectScaleHeight;
        coinDiameter  = carWidth;
        SetGameVelocity(gameVelocity);
        carSprite = new CarSprite(getResizedBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.car3), carWidth, carHeight));
        backGroundScrollVertical = new CarBackGroundScrollVertical(BitmapFactory.decodeResource(getResources(), R.drawable.roadgrey));
        backGroundScrollVertical.setVector(gameSpeed);

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        SetGameVelocity(gameSpeed);

        spawnPosition = new ArrayList<Integer>();
        spawnPosition.add(0);
        spawnPosition.add(1);
        spawnPosition.add(2);
        spawnPosition.add(3);
        spawnPosition.add(4);
        spawnPosition.add(5);

        int scale = CarSprite.screenWidth / 12 ; //6 lane highway


        laneNo =new ArrayList<Integer>();
        laneNo.add(scale);
        laneNo.add(3*scale);
        laneNo.add(5*scale);
        laneNo.add(7*scale);
        laneNo.add(9*scale);
        laneNo.add(11*scale);

        DistanceNo =new ArrayList<Integer>();
        DistanceNo.add(150);
        DistanceNo.add(450);
        DistanceNo.add(750);
        DistanceNo.add(1050);
        DistanceNo.add(1350);
        DistanceNo.add(750);
        DistanceNo.add(450);

        collisionDetect = new CollisionDetect();
        thread.setRunning(true);
        thread.start();
        makeLevel();


    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void InitAudio() {
        //AUDIO Initialisation
        //Other audio settings are called in Car GameBrick View
        mp = MediaPlayer.create(contextLocal, R.raw.carbg);

        attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        sp = new SoundPool.Builder()
                .setMaxStreams(10)
                .setAudioAttributes(attrs)
                .build();

        soundIds[0] = sp.load(contextLocal, R.raw.carcrash, 1);
        soundIds[1] = sp.load(contextLocal, R.raw.carcoin, 1);
        soundIds[2] = sp.load(contextLocal,R.raw.applause,1);

    }

    private void makeLevel() {
        Bitmap bmp;
        Bitmap bmp2;
        Bitmap bmp3;
        Bitmap bmp4;
        int y;
        int x;


        bmp = getResizedBitmap(BitmapFactory.decodeResource
                (getResources(), R.drawable.carleft), carWidth,  carHeight);
        bmp2 = getResizedBitmap
                (BitmapFactory.decodeResource(getResources(), R.drawable.truckright), carWidth, carHeight);
        bmp3 = getResizedBitmap(BitmapFactory.decodeResource
                (getResources(), R.drawable.extra2), carWidth,  carHeight);
        bmp4 = getResizedBitmap(BitmapFactory.decodeResource
                (getResources(), R.drawable.coin), coinDiameter, coinDiameter);

        //Collections.shuffle(laneNo);
        car = new CarObstacleSprite(bmp,laneNo.get(0), -DistanceNo.get(0));
        car.curLaneNo = laneNo.get(0);
        coin =  new CarObstacleSprite(bmp4,laneNo.get(1),-DistanceNo.get(2));
        coin.curLaneNo = laneNo.get(1);
        truck = new CarObstacleSprite(bmp2,laneNo.get(2), -DistanceNo.get(3));
        truck.curLaneNo = laneNo.get(2);
        other = new CarObstacleSprite(bmp3,laneNo.get(3), -DistanceNo.get(1));
        other.curLaneNo = laneNo.get(3);
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) { }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry =true; // Can take multiple attempts to destroy a thread
        if(mp!=null)
        {
            if(mp.isPlaying())
            {
                mp.stop();
            }
            mp.release();
        }
        if (sp != null) {
            sp.release();
        }
        while (retry)
        {
            try{
                thread.setRunning(false);
                thread.join();
                retry = false;
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

        }
    }

    public void update()    {
        if(gameStarted && gameNotPaused)
        {
            backGroundScrollVertical.setVector(gameSpeed+4);
            gameVelocity = gameSpeed;
        }

        backGroundScrollVertical.update();
        carSprite.update();
        car.update();
        other.update();
        truck.update();
        coin.update();
        logic();
    }
    @Override
    public void draw(Canvas canvas)    {
        super.draw(canvas);

        if (canvas != null) {
            backGroundScrollVertical.draw(canvas);
            carSprite.draw(canvas);
            car.draw(canvas);
            other.draw(canvas);
            truck.draw(canvas);
            coin.draw(canvas);

        }
    }
    public static Bitmap getResizedBitmap(Bitmap bm, int newWidth, int newHeight) {
        int width = bm.getWidth();
        int height = bm.getHeight();
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height;
        // CREATE A MATRIX FOR THE MANIPULATION
        Matrix matrix = new Matrix();
        // RESIZE THE BIT MAP
        matrix.postScale(scaleWidth, scaleHeight);
        // "RECREATE" THE NEW BITMAP
        Bitmap resizedBitmap = Bitmap.createBitmap(bm, 0, 0, width, height, matrix, false);
        bm.recycle();
        return resizedBitmap;
    }
    public void logic()    {

        obstacles = new ArrayList<>();
        boolean isCollided ;

        obstacles.add(car);
        obstacles.add(coin);
        obstacles.add(truck);
        obstacles.add(other);

        for (int i = 0; i < obstacles.size(); i++) {

            isCollided=collisionDetect.isCollisionDetected(carSprite.image,carSprite.x,carSprite.y,obstacles.get(i).image,obstacles.get(i).xX,obstacles.get(i).yY);
            if(isCollided && gameNotPaused)
            {
                resetLevel(i);
            }

            spawnObject(i); //If obstacle goes out of bounds

        }

    }
    public void resetLevel(int i)    {
            Log.d("Obstacle Y", Integer.toString(obstacles.get(i).yY));
            int offsetObstacle = CarSprite.screenHeight - obstacles.get(i).yY;
            GenerateSpawnLocation(i,offsetObstacle);

            if (i == 0 || i ==2 || i ==3)
            {
                PauseGame();
                CarSprite.doSet=true; //make false if you want to stop movement of car
                PlayShortAudio(0);
                carSprite.blink(getResizedBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.car4), carWidth, carHeight));
                new Timer().schedule(new TimerTask() {
                    @Override
                    public void run() {
                        carSprite.setImage(getResizedBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.car3), carWidth, carHeight));
                        ResumeGame();
                        CarSprite.doSet=true;
                        if(gameScore < 1){}
                        else{
                            gameScore--;
                            carGameActivity.setScore(gameScore);
                        }

                        // this code will be executed after 2 seconds
                    }
                }, 1000);
                prevCollision =i;
            }
            else
            {
                PlayShortAudio(1);
                gameScore++;
                carGameActivity.setScore(gameScore);

            }


           //Log.d("Score ", Integer.toString(gameScore));
    }
    private void spawnObject(int i)    {

        if(obstacles.get(i).yY > CarSprite.screenHeight)
        {
            GenerateSpawnLocation(i, 0);
        }
    }
    private void GenerateSpawnLocation(int i, int offset) {
        if (spawnCounter >= 4)
        {
            spawnCounter =0;
            Collections.shuffle(spawnPosition);
        }
        Random r = new Random();
        value1 = r.nextInt(20);
        value2 = spawnPosition.get(spawnCounter);
        obstacles.get(i).xX = value1 + laneNo.get(value2);
        obstacles.get(i).yY = -(DistanceNo.get(1)+ offset);
        spawnCounter++;
    }
    public void PauseGame()    {
        gameNotPaused = false;
        ControlBackgroundMusic(musicOff);
        SetGameVelocity(0);
        backGroundScrollVertical.setVector(0);
    }
    public void ResumeGame()
    {
        gameNotPaused = true;
        gameStarted = true;
        ControlBackgroundMusic(musicOn);
    }
    public static void SetGameVelocity(int i) {
        gameVelocity = i;
    }
    public void PlayShortAudio(int audioIndex)    {
        if(audioIndex == 0) {
            sp.stop(1);
            sp.stop(0);
            sp.stop(2);
            sp.play(soundIds[0], 0.3f, 0.3f, 1, 0, 1.0f);
        }
        else if(audioIndex == 1){
            sp.stop(1);
            sp.stop(0);
            sp.stop(2);
            sp.play(soundIds[1], 0.91f, 0.91f, 1, 0, 1.0f);
        }
        else if (audioIndex == 2){
            sp.stop(0);
            sp.stop(1);
            sp.stop(2);
            sp.play(soundIds[2], 0.4f, 0.4f, 1, 0, 1.0f);
        }
    }
    public void EndGame(){
        boolean retry =true; // Can take multiple attempts to destroy a thread
        if(mp!=null)
        {
            if(mp.isPlaying())
            {
                mp.stop();
            }
            mp.release();
        }
        if (sp != null) {
            sp.release();
        }
        while (retry)
        {
            try{
                thread.setRunning(false);
                thread.join();
                retry = false;
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

        }

    }
    public int getScore(){
        return gameScore;
    }
    public void StartBackgroundMusic() {
        mp.start();
        mp.setLooping(true);
        mp.setVolume(0.6f, 0.6f); //scales logarithmically between 0 and 1
    }
    public void ControlBackgroundMusic( int musicState){
        try {
            if (mp != null && musicState == 1 && mp.isPlaying() == false) {
                mp.start();
            }
            if (mp != null && musicState == 0 && mp.isPlaying()) {
                mp.pause();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
