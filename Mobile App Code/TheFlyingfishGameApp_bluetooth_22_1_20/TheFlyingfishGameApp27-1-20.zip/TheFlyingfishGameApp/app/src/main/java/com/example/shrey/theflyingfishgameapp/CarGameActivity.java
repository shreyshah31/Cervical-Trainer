package com.example.shrey.theflyingfishgameapp;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.example.shrey.theflyingfishgameapp.CarGame.CarGameView;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

import static java.lang.Math.abs;

//import com.example.shrey.theflyingfishgameapp.Tables.Scores;
//import com.sdsmdg.tastytoast.TastyToast;
//import co.lujun.lmbluetoothsdk.BluetoothController;
//import co.lujun.lmbluetoothsdk.base.BluetoothListener;
//import co.lujun.lmbluetoothsdk.base.State;
//import static com.roborehab.MainActivity.mConnectState;


public class CarGameActivity<mp> extends Activity {

    Context context = this;
//    Scores mScores;

    private Handler handler = new Handler();
    //    private BluetoothController mBluetoothController = MainActivity.mBluetoothController;
    public CarGameView carGameView;
    public FrameLayout frameLayout;

    private TextView tvSpeed, tvTime, tvRomDebug, tvStrengthValue;

    public static TextView tvScore;

    public Button btnSlow, btnSlowPressed, btnMedium, btnMediumPressed, btnFast, btnFastPressed,
            btnFinish, btnRestart, btnTimeMinus, btnTimePlus, btnMinus, btnPlus, btnPause;

    private ImageView ivIntro, ivLineRed, ivLineYellow;

    private Timer timer = new Timer();
    CountDownTimer cTimer = null;
    public long currentcounttime, pausecounttimmer;
    private boolean startFlag = false, actionFlag = false, dataflag;
    public int strengthVal = 128, initGameSpeed = 5, score = 0,
            initialStrengthVal = 0;
    int liTime = 5;

    private static String GAME_NAME = "Car";
    private String rxdata = "", posdata;
    double strengthNm = 0.0;

    //Filter
    int emaS = 0;
    float emaAlpha = 0.4f;

    //Position
    private int newAngle, position, offSet, prevPos, angle, maxAngleL = 180,
            maxAngleR = 180, maxAngle = 180, minval = 320, maxval = 680;
    public static int locationCarSprite, maxXOnScreen,
            minXOnScreen;
    private float rangePercent = 1.0f;
    boolean lbFirstTime = false, prevflag = false, startMoving = false;

    //End of game parameters
    private int maxGameAngleL = 0, maxGameAngleR = 0;
    private double maxGameStrength = 0.0;
    public static String stringMaxAngleL = "maxAngleL", stringMaxAngleR = "maxAngleR", stringMaxStrength = "maxStrength", stringMaxScore = "maxScore";
    boolean gameEnded = true;
    int time, speed;
    public static int mscreenheight;
    public static int mscreenwidth;

    //
    private final String DEVICE_ADDRESS = "98:D3:51:F5:E4:A0";// 00:18:E4:40:00:06-roborehab ka hai //98:D3:51:F5:E4:A0-yeh wala mere bluetooth ka hai
    private final UUID PORT_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");//Serial Port Service ID
    private InputStream inputStream;
    private OutputStream outputStream;
    boolean deviceConnected;
    private int ekkbaar = 0;
    byte buffer[];
    private BluetoothDevice device;
    boolean stopThread;
    private String stringnewd;
    private String datad;
    private int vald = 0, valdy = 0;
    private String thodd;
    private String thoddy;
    private int once, xprint;
    private int datamila = 0;
    String laststr;
    private int o = 0;
    private int slen = 0;
    int z = 0;
    String stringd;
    String thodd1;
    private int range = 3;
    private int x2 = 0;
    Thread workerThread;
    byte[] readBuffer;
    int readBufferPosition;
    volatile boolean stopWorker;
    public BluetoothSocket socket = BluetoothActivity.socket;
    String thodr;
    int valdr = 0;
    //

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        mscreenheight = displayMetrics.heightPixels + getNavigationBarHeight();
        mscreenwidth = displayMetrics.widthPixels;
        maxXOnScreen = mscreenwidth - (mscreenwidth / 10);
        minXOnScreen = maxXOnScreen / 30;
        carGameView = new CarGameView(this);
        setContentView(R.layout.activity_car_game);


//        displayHeight = mscreenheight + getNavigationBarHeight();
//        displayWidth = mscreenwidth;

       /* mscreenheight = frameLayout.getHeight();
        mscreenwidth = frameLayout.getWidth();*/

        //LinearLayout llHeader = findViewById(R.id.llHeader);
        //llHeader.setVisibility(View.GONE);

        View overlay = findViewById(R.id.activity_car_game);
        overlay.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN);

        //Other audio settings are called in Car GameBrick View
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        //Database
        //mScores = new Scores(this);
        //Buttons for Speed
//        btnSlow = findViewById(R.id.btnSlow);
//        btnSlowPressed = findViewById(R.id.btnSlowPressed);
//        btnFast = findViewById(R.id.btnFast);
//        btnFastPressed = findViewById(R.id.btnFastPressed);
//        btnMedium = findViewById(R.id.btnMedium);
//        btnMediumPressed = findViewById(R.id.btnMediumPressed);
//        btnMinus = findViewById(R.id.btnMinus);
//        btnPlus = findViewById(R.id.btnPlus);
//        btnTimePlus = findViewById(R.id.btnTimePlus);
//        btnTimeMinus = findViewById(R.id.btnTimeMinus);
//
//        btnSlow.setVisibility(View.INVISIBLE);
//        btnMediumPressed.setVisibility(View.INVISIBLE);
//        btnFastPressed.setVisibility(View.INVISIBLE);
//        btnPause = findViewById(R.id.btnPause);
//        btnFinish = findViewById(R.id.btnFinish);
//        btnRestart = findViewById(R.id.btnRestart);

        //Image Views
//        ivIntro = findViewById(R.id.ivIntro);
//        ivLineRed = findViewById(R.id.ivLineRed);
//        ivLineYellow = findViewById(R.id.ivLineYellow);
//
//        ivLineYellow.setVisibility(View.INVISIBLE);
//        ivLineRed.setVisibility(View.INVISIBLE);
//
//        //Text Views
//        tvRomDebug = findViewById(R.id.tvRomDebug);
//        tvRomDebug.setVisibility(View.GONE);
//        tvScore = findViewById(R.id.tvScore);
//        tvSpeed = findViewById(R.id.tvSpeed);
//        tvTime = findViewById(R.id.tvTime);
//        tvStrengthValue = findViewById(R.id.tvStrengthValue);
//
//
//        maxAngleL = getIntent().getIntExtra(TrainingActivity.LEFT_RANGE, maxAngleL);
//        maxAngleR = getIntent().getIntExtra(TrainingActivity.RIGHT_RANGE, maxAngleR);
//        strengthVal = getIntent().getIntExtra(TrainingActivity.STRENGTH, strengthVal);
//        time = getIntent().getIntExtra(GamesSetting.GAME_TIME, time);
//        speed = getIntent().getIntExtra(GamesSetting.GAME_SPEED, speed);
//        initialStrengthVal = strengthVal;
//        strengthNm = 0.012132 * strengthVal;
//        strengthNm = 0.012132 * strengthVal;

        //Initialise Text Views
//        tvScore.setText(Integer.toString(0));
//        tvStrengthValue.setText(String.format("%.2f", strengthNm) + " Nm");
//        mBluetoothController.write(("a" + (strengthVal + 300)).getBytes());
        //Initialise Bluetooth
//        init();

//        btnSlow.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                initGameSpeed = 5;
//                carGameView.gameSpeed = 5;
//                btnSlowPressed.setVisibility(View.VISIBLE);
//                btnMedium.setVisibility(View.VISIBLE);
//                btnFast.setVisibility(View.VISIBLE);
//                btnSlow.setVisibility(View.INVISIBLE);
//                btnMediumPressed.setVisibility(View.INVISIBLE);
//                btnFastPressed.setVisibility(View.INVISIBLE);
//            }
//        });
//
//        btnMedium.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                initGameSpeed = 7;
//                carGameView.gameSpeed = 7;
//                btnMediumPressed.setVisibility(View.VISIBLE);
//                btnSlow.setVisibility(View.VISIBLE);
//                btnFast.setVisibility(View.VISIBLE);
//                btnMedium.setVisibility(View.INVISIBLE);
//                btnSlowPressed.setVisibility(View.INVISIBLE);
//                btnFastPressed.setVisibility(View.INVISIBLE);
//            }
//        });
//        btnFast.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                initGameSpeed = 9;
//                carGameView.gameSpeed = 9;
//                btnFastPressed.setVisibility(View.VISIBLE);
//                btnMedium.setVisibility(View.VISIBLE);
//                btnSlow.setVisibility(View.VISIBLE);
//                btnFast.setVisibility(View.INVISIBLE);
//                btnMediumPressed.setVisibility(View.INVISIBLE);
//                btnSlowPressed.setVisibility(View.INVISIBLE);
//            }
//        });
//        btnMinus.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View view) {
//                if (strengthVal >= 10) {
//                    strengthVal = strengthVal - 10;
//                } else if (strengthVal > 0) {
//                    strengthVal = strengthVal - 1;
//                }
//                strengthNm = 0.012132 * strengthVal;
//                tvStrengthValue.setText(String.format("%.2f", strengthNm) + " Nm");
//                mBluetoothController.write(("a" + (strengthVal + 300)).getBytes());
//                return true;
//            }
//        });
//        btnPlus.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View view) {
//                if (strengthVal <= 245) {
//                    strengthVal = strengthVal + 10;
//                } else if (strengthVal < 255) {
//                    strengthVal = strengthVal + 1;
//                }
//                strengthNm = 0.012132 * strengthVal;
//                tvStrengthValue.setText(String.format("%.2f", strengthNm) + " Nm");
//                mBluetoothController.write(("a" + (strengthVal + 300)).getBytes());
//                return true;
//            }
//        });
//        btnMinus.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (strengthVal >= 2) {
//                    strengthVal = strengthVal - 2;
//                } else if (strengthVal > 0) {
//                    strengthVal = strengthVal - 1;
//                }
//                strengthNm = 0.012132 * strengthVal;
//                tvStrengthValue.setText(String.format("%.2f", strengthNm) + " Nm");
//                mBluetoothController.write(("a" + (strengthVal + 300)).getBytes());
//            }
//        });
//        btnPlus.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (strengthVal <= 253) {
//                    strengthVal = strengthVal + 2;
//                } else if (strengthVal < 255) {
//                    strengthVal = strengthVal + 1;
//                }
//                strengthNm = 0.012132 * strengthVal;
//                tvStrengthValue.setText(String.format("%.2f", strengthNm) + " Nm");
//                mBluetoothController.write(("a" + (strengthVal + 300)).getBytes());
//            }
//        });
//        btnTimeMinus.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                decrementTime();
//            }
//        });
//        btnTimePlus.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                incrementTime();
//            }
//        });
//        ivIntro.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                btnTimeMinus.setVisibility(View.GONE);
//                btnTimePlus.setVisibility(View.GONE);
//                startGame();
//            }
//        });
//
//        btnPause.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (carGameView.gameNotPaused == true)//
//                {
//                    carGameView.PauseGame();
//                    cTimer.cancel();
//                } else {
//                    carGameView.ResumeGame();
//                    setTimeLength();
//                    cTimer.start();
//
//                }
//            }
//        });
//
        startGame();
//
//        btnFinish.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mBluetoothController.write("z\n".getBytes());
//                carGameView.PauseGame();
//                new Timer().schedule(new TimerTask() {
//                    @Override
//                    public void run() {
//                        FinishGame();
//                        Intent intent = new Intent(CarGameActivity.this, GameReportActivity.class);
//                        intent.putExtra(TrainingActivity.LEFT_RANGE, maxAngleL);
//                        intent.putExtra(TrainingActivity.RIGHT_RANGE, maxAngleR);
//                        intent.putExtra(TrainingActivity.STRENGTH, initialStrengthVal);
//                        intent.putExtra(stringMaxScore, carGameView.getScore());
//                        intent.putExtra(stringMaxAngleL, maxGameAngleL);
//                        intent.putExtra(stringMaxAngleR, maxGameAngleR);
//                        maxGameStrength = strengthNm;
//                        intent.putExtra(stringMaxStrength, maxGameStrength);
//                        startActivity(intent);
//                        // this code will be executed after 2 seconds
//                    }
//                }, 500);
//            }
//        });
//
//        btnRestart.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(getIntent());
//                finish();
//                overridePendingTransition(0, 0);
//
//            }
//        });
//        showLastScores();

        if (speed == 0) {
            initGameSpeed = 5;
            carGameView.gameSpeed = 5;
        } else if (speed == 1) {
            initGameSpeed = 7;
            carGameView.gameSpeed = 7;
        } else {
            initGameSpeed = 9;
            carGameView.gameSpeed = 9;
        }

    }

    public void setScore(int score1) {
        score = score1;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
              //  tvScore.setText(Integer.toString(score));
            }
        });
    }


    private int getNavigationBarHeight() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            DisplayMetrics metrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(metrics);
            int usableHeight = metrics.heightPixels;
            getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
            int realHeight = metrics.heightPixels;
            if (realHeight > usableHeight)
                return realHeight - usableHeight;
            else
                return 0;
        }
        return 0;
    }

//    private void init() {
//        mBluetoothController.setBluetoothListener(new BluetoothListener() {
//            @Override
//            public void onActionStateChanged(int preState, int state) {
//            }
//
//            @Override
//            public void onActionDiscoveryStateChanged(String discoveryState) {
//            }
//
//            @Override
//            public void onActionScanModeChanged(int preScanMode, int scanMode) {
//            }
//
//            @Override
//            public void onBluetoothServiceStateChanged(final int state) {
//                // If you want to update UI, please run this on UI thread
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        mConnectState = state;
//                        if (mConnectState != State.STATE_CONNECTED) {
//                            TastyToast.makeText(context, "Bluetooth Connection Lost", TastyToast.LENGTH_LONG, TastyToast.ERROR).show();
//                            mConnectState = State.STATE_DISCONNECTED;
//                            finish();
//                        }
//                    }
//                });
//            }
//
//            @Override
//            public void onActionDeviceFound(BluetoothDevice device, short rssi) {
//            }
//
//            @Override
//            public void onReadData(final BluetoothDevice device, final byte[] data) {
//                // If you want to update UI, please run this on UI thread
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//
//                        rxdata = rxdata + new String(data);
////                        Toast.makeText(ShootingGameActivity.this, rxdata, Toast.LENGTH_SHORT).show();
//                        if (!actionFlag && rxdata.contains("g")) {
//
//                            actionFlag = true;
//                            timer.schedule(new TimerTask() {
//                                @Override
//                                public void run() {
//                                    handler.post(new Runnable() {
//                                        @Override
//                                        public void run() {
//                                            changePos();
//                                        }
//                                    });
//                                }
//                            }, 0, 20);
//                        } else if (rxdata.contains("\n") && actionFlag) {
//                            try {
//                                posdata = rxdata.substring(rxdata.lastIndexOf('\n') - 3, rxdata.lastIndexOf('\n'));
//                                mBluetoothController.write("w\n".getBytes());
//                                dataflag = true;
//                            } catch (Exception e) {
//                            }
//                        }
//                    }
//                });
//            }
//        });
//    }

    public void startGame() {
        if (!startFlag) {
            //Start GameBrick in Frame and Pause game
//            if (ivIntro.getParent() != null) {
//                ((ViewGroup) ivIntro.getParent()).removeView(ivIntro); // <- fix
//            }
            setUiEnabled(true);
            frameLayout = findViewById(R.id.frame);
            frameLayout.addView(carGameView);
            carGameView.gameSpeed = initGameSpeed;
            CarGameView.gameScore = 0;
            carGameView.StartBackgroundMusic();
            carGameView.ResumeGame();
            startFlag = true;
//            currentcounttime = (liTime * 60 * 1000);
//            setTimeLength();
//            cTimer.start();
//            mBluetoothController.write("g\ng\n".getBytes());
//            mBluetoothController.write(("a" + (strengthVal + 300)).getBytes());
//            mBluetoothController.write(("a" + (strengthVal + 300)).getBytes());
            lbFirstTime = true;
            prevflag = true;

        }

    }

    private void incrementTime() {
        liTime = liTime + 1;
        updateTimeDisplay();
    }

    private void decrementTime() {
        if (liTime > 1) {
            liTime = liTime - 1;
            updateTimeDisplay();
        }
    }

    private void updateTimeDisplay() {
        tvTime.setText("" + liTime + ":00");
    }

//    public void updateScore() {
//
//        String lsScore = Integer.toString(carGameView.getScore());
//        int liScore = App.String2Int(lsScore);
//        if (liScore > 0) {
//            ContentValues cv = new ContentValues();
//            cv.put(Scores.SCR_PTID, App.getPatientID());
//            cv.put(Scores.SCR_SESSIONID, App.getSession());
//            cv.put(Scores.SCR_GAME, GAME_NAME);
//            cv.put(Scores.SCR_SCORE, liScore);
//            mScores.updateData(cv);
//        }
//    }

    private void init_ema(int raw_val) {
        emaS = raw_val;
    }

    int get_ema(int raw_val) {
        float x;
        x = (emaAlpha * raw_val) + ((1 - emaAlpha) * emaS); //after * by float result is float
        emaS = (int) x;
        return emaS;
    }

    public float map(float x, float xmin, float xmax, float ymin, float ymax) {
        return (ymax - ymin) / (xmax - xmin) * (x - xmin) + ymin;
    }

    public float publicLimit(float x, float max, float min) {
        float newX = 0.0f;
        if (x <= min) {
            newX = min;
        } else if (x >= max) {
            newX = max;
        } else {
            newX = x;
        }
        return newX;
    }

    public void changePos() {
        Log.d("Score Global", Integer.toString(score));
        if (dataflag && posdata.length() == 3) {
            try {
                if (lbFirstTime) {
                    position = Integer.parseInt(posdata);
                    offSet = position - 500;
                    init_ema(newAngle);
                    lbFirstTime = false;
                }
                if (prevflag) {
                    prevPos = position;
                    angle = (int) map(position, minval, maxval, -maxAngle, maxAngle) - offSet;
                    prevflag = false;
                    startMoving = true;
                }
                if (startMoving) {
                    position = Integer.parseInt(posdata);

                    if (abs(position - prevPos) > 0) {
                        angle = (int) map(position, minval, maxval, -maxAngle, maxAngle) - offSet;
                        prevPos = position;
                    }
                    if (abs(angle) > 180) {
                        if (offSet > 0) {
                            newAngle = 180 - (abs(angle) % 180);
                        } else {
                            newAngle = -180 + (abs(angle) % 180);
                        }
                    } else {
                        newAngle = angle;
                    }
                    if (abs(newAngle) > 175) {
                        newAngle = newAngle;
                        emaS = newAngle;
                    } else {
                        newAngle = get_ema(newAngle);
                    }
                    if (newAngle <= 0 && newAngle < maxGameAngleL) {
                        maxGameAngleL = newAngle;
                    }
                    if (newAngle >= 0 && newAngle > maxGameAngleR) {
                        maxGameAngleR = newAngle;
                    }
                    Log.d("Angle", Integer.toString(newAngle));
                    locationCarSprite = (int) map(newAngle, -maxAngleL * rangePercent, maxAngleR * rangePercent, minXOnScreen, maxXOnScreen);
                    locationCarSprite = (int) publicLimit(locationCarSprite, maxXOnScreen, minXOnScreen);
                }
            } catch (Exception e) {

            }
            dataflag = false;
        }
        //   tvRomDebug.setVisibility(View.VISIBLE);
        //   tvRomDebug.setText(locationCarSprite +" "+ maxAngleR*rangePercent+" " + maxAngleL*rangePercent);
    }

    public void setTimeLength() {
        cTimer = new CountDownTimer(currentcounttime, 1000) {

            public void onTick(long millisUntilFinished) {
                currentcounttime = millisUntilFinished;
                long llMillis = millisUntilFinished / 1000;
                long llSeconds = llMillis % 60;
                int liMin = (int) (llMillis / 60.0f);
                if (llSeconds < 10) {
                    tvTime.setText(" " + liMin + " : 0" + llSeconds);
                } else {
                    tvTime.setText(" " + liMin + " : " + llSeconds);
                }
                if (millisUntilFinished < (((liTime * 60 * 1000) * 25) / 100)) {
                    rangePercent = 1.2f;
                } else if (millisUntilFinished < (((liTime * 60 * 1000) * 75) / 100)) {
                    rangePercent = 1.1f;
                }
            }

            public void onFinish() {
//                mBluetoothController.write("z\n".getBytes());
                carGameView.PauseGame();
                carGameView.PlayShortAudio(2); //Applause
                new Timer().schedule(new TimerTask() {
                    @Override
                    public void run() {
//                        updateScore();
                        FinishGame();
//                        Intent intent = new Intent(CarGameActivity.this, GameReportActivity.class);
//                        intent.putExtra(TrainingActivity.LEFT_RANGE, maxAngleL);
//                        intent.putExtra(TrainingActivity.RIGHT_RANGE, maxAngleR);
//                        intent.putExtra(TrainingActivity.STRENGTH, initialStrengthVal);
//                        intent.putExtra(stringMaxScore, carGameView.getScore());
//                        intent.putExtra(stringMaxAngleL, maxGameAngleL);
//                        intent.putExtra(stringMaxAngleR, maxGameAngleR);
//                        maxGameStrength = strengthNm;
//                        intent.putExtra(stringMaxStrength, maxGameStrength);
//                        startActivity(intent);
                        // this code will be executed after 2 seconds
                    }
                }, 3000);
            }
        };
    }

//    private void showLastScores() {
//        TextView tvHighScore = findViewById(R.id.tvHighScrore);
//        TextView tvLastScore = findViewById(R.id.tvLastScore);
//
//        int liHigh = mScores.getHighScore(App.getPatientID(), GAME_NAME);
//        int liLast = mScores.getLastScore(App.getPatientID(), GAME_NAME);
//
//        if (liHigh > 0) tvHighScore.setText("High Score : " + liHigh);
//        if (liLast > 0) tvLastScore.setText("Last Score : " + liLast);
//    }

    private void FinishGame() {
        if (gameEnded) {

            gameEnded = false;
            if (timer != null) {
                timer.cancel();
                timer = null;
            }

//            mBluetoothController.write("z\n".getBytes());
//            if (cTimer != null) {
//                cTimer.cancel();
//            }
//            if (mBluetoothController != null) {
//                mBluetoothController.write("a300".getBytes());
//            }
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            carGameView = new CarGameView(this);
        }
        setContentView(R.layout.activity_car_game);
        frameLayout = findViewById(R.id.frame);
        frameLayout.addView(carGameView);

        setScore(0);
        carGameView.StartBackgroundMusic();
        carGameView.ResumeGame();
        View overlay = findViewById(R.id.activity_car_game);
        overlay.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        FinishGame();
    }


    //
    long map(long x, long in_min, long in_max, long out_min, long out_max) {
        return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
    }


// IDDHAR SE BLUETOOTH CHALU HOTA HAI

    public void setUiEnabled(boolean bool) {
        if (ekkbaar == 0) {
            Start();
        }

    }


    public boolean BTinit() {
        boolean found = false;
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(CarGameActivity.this,"Device doesnt Support Bluetooth",Toast.LENGTH_SHORT).show();
        }
        if (!bluetoothAdapter.isEnabled()) {
            Intent enableAdapter = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }


        Set<BluetoothDevice> bondedDevices = bluetoothAdapter.getBondedDevices();
        if (bondedDevices.isEmpty()) {
            Toast.makeText(CarGameActivity.this,"Please Pair the Device first",Toast.LENGTH_SHORT).show();
        } else {
            for (BluetoothDevice iterator : bondedDevices) {
                if (iterator.getAddress().equals(DEVICE_ADDRESS)) {
                    device = iterator;
                    found = true;
                    break;
                }
            }
        }
        return found;
    }


    public boolean BTconnect() {
        boolean connected = true;
        try {
            socket = device.createRfcommSocketToServiceRecord(PORT_UUID);
            socket.connect();
        } catch (IOException e) {
            e.printStackTrace();
            connected = false;
        }
        if (connected) {
            try {
                outputStream = socket.getOutputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                inputStream = socket.getInputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return connected;
    }


    public void Start() {
        if (BTinit()) {
            if (BTconnect()) {
                ekkbaar = 1;
                setUiEnabled(true);
                deviceConnected = true;
                beginListenForData();
                Toast.makeText(CarGameActivity.this,"COnnection Opened \n",Toast.LENGTH_SHORT).show();
            }
        }
    }


    void beginListenForData() {

//        final Handler handler = new Handler();
//        stopThread = false;
//        buffer = new byte[1024];
//        Thread thread  = new Thread(new Runnable()
//
//        {
//
//            public void run()
//
//            {
//                while(!Thread.currentThread().isInterrupted() && !stopThread)
//                {
//                    try
//                    {
//                        int byteCount = inputStream.available();
//                        if(byteCount > 0)
//                        {
//                            byte[] rawBytes = new byte[byteCount];
//                            inputStream.read(rawBytes);
//                            stringd=new String(rawBytes,"UTF-8");
//                            stringnewd=stringd;
//                            handler.post(new Runnable()
//                            {
//
//                                public void run()
//
//                                {
//                                }
//
//                            });
//                        }
//                    }
//                    catch (IOException ex)
//                    {
//                        stopThread = true;
//                    }
//                }
//
//            }
//        });
//        thread.start();
        try {
            final Handler handler = new Handler();

            // this is the ASCII code for a newline character
            final byte delimiter = 10;

            stopWorker = false;
            readBufferPosition = 0;
            readBuffer = new byte[1024];

            workerThread = new Thread(new Runnable() {
                public void run() {

                    while (!Thread.currentThread().isInterrupted() && !stopWorker) {

                        try {

                            int bytesAvailable = inputStream.available();

                            if (bytesAvailable > 0) {

                                byte[] packetBytes = new byte[bytesAvailable];
                                inputStream.read(packetBytes);

                                for (int i = 0; i < bytesAvailable; i++) {

                                    byte b = packetBytes[i];
                                    if (b == delimiter) {

                                        byte[] encodedBytes = new byte[readBufferPosition];
                                        System.arraycopy(
                                                readBuffer, 0,
                                                encodedBytes, 0,
                                                encodedBytes.length
                                        );

                                        // specify US-ASCII encoding
                                        final String data = new String(encodedBytes, "US-ASCII");
                                        readBufferPosition = 0;

                                        // tell the user data were sent to bluetooth printer device
                                        handler.post(new Runnable() {
                                            public void run() {
                                                stringd = data;
                                                //Log.d(TAG, "inputstream:" + data);
                                                //myLabel.setText(data);
                                                dataupdate();
                                            }
                                        });

                                    } else {
                                        readBuffer[readBufferPosition++] = b;
                                    }
                                }
                            }

                        } catch (IOException ex) {
                            stopWorker = true;
                        }

                    }
                }
            });

            workerThread.start();

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    public void datasend(String s1) {
        String string = s1;
        //string.concat("\n");
        try {
            outputStream.write(string.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void ConClose() throws IOException {

        stopThread = true;
        outputStream.close();
        inputStream.close();
        socket.close();
        setUiEnabled(false);
        deviceConnected = false;
    }
    //

    public void dataupdate() {
        datad = stringd;
        try {
            slen = datad.length();
        } catch (Exception e) {
            e.printStackTrace();
        }

//            data1();
//            data2();
//            data3();

        try {
                  /*  int index1 = datad.indexOf("z");
                    int index2 = datad.indexOf("s");
                    thodd = datad.substring(index1, index2);
                     int slen1=thodd.length();
                     thodd1=thodd.substring(1,slen1);
                     */
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            // vald=Integer.parseInt(thodd1);


            if (datad == "y") {

            } else {
                if (slen >= 3) {
                    int index1 = datad.indexOf("y");
                    thodd = datad.substring(index1 - 3, index1);
                    vald = Integer.parseInt(thodd);
                    vald = vald - 360;


                }
            }


            if (datad == "p") {

            } else {
                if (slen >= 3) {
                    int index11 = datad.indexOf("p");
                    thoddy = datad.substring(index11 - 3, index11);
                    valdy = Integer.parseInt(thoddy);
                    valdy = valdy - 360;
                }
            }


            if (datad == "r") {

            } else {
                if (slen >= 3) {
                    int index12 = datad.indexOf("r");
                    thodr = datad.substring(index12 - 3, index12);
                    valdr = Integer.parseInt(thodr);
                    valdr = valdr - 360;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        locationCarSprite = (int) map(vald, 90, 270, minXOnScreen, maxXOnScreen);

    }
}
