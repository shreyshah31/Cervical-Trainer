package com.example.shrey.theflyingfishgameapp;

import android.app.AlertDialog;
import android.bluetooth.BluetoothSocket;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    public BluetoothSocket socket=BluetoothActivity.socket;
    private FlyingFishView gameView;
    private Handler handler=new Handler();
    private static long Interval=30;
    private int dialogclear=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showGameIntroDialog();
       gameView = new FlyingFishView(this);
       setContentView(gameView);

       Timer timer=new Timer();
       timer.schedule(new TimerTask() {
           @Override
           public void run() {
               handler.post(new Runnable() {
                   @Override
                   public void run() {
                       if(dialogclear>=1) {
                           gameView.invalidate();
                       }
                   }
               });
           }
       },0,Interval);
    }

    public void showGameIntroDialog() {
        //dialog
        int ui_flags =  View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
        final AlertDialog.Builder alert = new AlertDialog.Builder(this);
        View mView = getLayoutInflater().inflate(R.layout.dialog_box, null);
        final Button btn_dialog_game = (Button) mView.findViewById(R.id.rangebtnplus);
        alert.setView(mView);
        final AlertDialog alertDialog = alert.create();
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        alertDialog.getWindow().getDecorView().setSystemUiVisibility(ui_flags);
        alertDialog.show();
        alertDialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
    alertDialog.getWindow().setLayout((int)(1280*0.8f),(int)(800*0.8f));
        final int[] countbtn = {0};
        btn_dialog_game.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogclear++;
                alertDialog.dismiss();
                //startGame();
                //to be added in rabbit and not in Aster device
                /*btn_dialog_game.setText("Start");

                countbtn[0]++;
                if (countbtn[0] == 2) {
                    countbtn[0] = 0;
                    alertDialog.dismiss();
                    startGame();
                }*/

            }
        });


    }
}
