package com.example.shrey.theflyingfishgameapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class DartViewNew extends AppCompatActivity {

    private ImageView blue_dart, red_dart;
    private FrameLayout dartframe;

    private int vald = 0, valdy = 0, valdr = 0, rangeVal = 3, rangeMin = 0, rangeMax = 0, repeatCountx = 0, repeatCounty = 0, repeatCountz = 0;
    private String thodd, thoddy, thodr;
    private int slen = 0;
    private float yaw, pitch, roll;

    private float yawRangeCheck = 0, pitchRangeCheck = 0, rollRangeCheck = 0;
    String patient_name;


    TextView xAxisText, yAxisText, zAxisText, rangeValText, repeatText;

    Button xaxis, yaxis, zaxis, rangeMinus, rangePlus, recordButton;

    private int xAxisVal = 0, yAxisVal = 0, zAxisVal = 0, n = 0;
    float random = 0, generator;
    private boolean once;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        // Set the content to appear under the system bars so that the
                        // content doesn't resize when the system bars hide and show.
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // Hide the nav bar and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);

        patient_name = getIntent().getStringExtra("patientName");
        setContentView(R.layout.activity_dart_view_new);

        dartframe = findViewById(R.id.dartframe);
        red_dart = findViewById(R.id.red_dart);
        blue_dart = findViewById(R.id.blue_dart);

        xAxisText = findViewById(R.id.x_axis_text);
        yAxisText = findViewById(R.id.y_axis_text);
        zAxisText = findViewById(R.id.z_axis_text);

        rangeValText = findViewById(R.id.range_value);

        repeatText = findViewById(R.id.repeat);

        xaxis = findViewById(R.id.xaxisdart);
        yaxis = findViewById(R.id.yaxisdart);
        zaxis = findViewById(R.id.zaxisdart);

        rangeMinus = findViewById(R.id.range_minus);
        rangePlus = findViewById(R.id.range_plus);

        recordButton = findViewById(R.id.recordbutton);

        xaxis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                xAxisVal = 1;
                yAxisVal = 0;
                zAxisVal = 0;
            }
        });
        yaxis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yAxisVal = 1;
                xAxisVal = 0;
                zAxisVal = 0;
            }
        });
        zaxis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                zAxisVal = 1;
                xAxisVal = 0;
                yAxisVal = 0;
            }
        });

        rangePlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rangeVal >= 1) {
                    rangeVal++;
                }
            }
        });

        rangeMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rangeVal > 1) {
                    rangeVal--;
                }
            }
        });

        recordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseActivity.Addanalysis(Integer.toString((int) yawRangeCheck), Integer.toString((int) rollRangeCheck), Integer.toString((int) pitchRangeCheck), patient_name);
            }
        });
        once = true;
    }

    @Override
    protected void onResume() {
        super.onResume();

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {

            @Override
            public void run() {

                dataupdate();
            }
        }, 0, 25);
    }

    float map(float x, float in_min, float in_max, float out_min, float out_max) {
        return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
    }

    public void dataupdate() {
        String datad = SplashActivity.bluetoothvalues_x_y_z;
        try {
            slen = datad.length();
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {

            if (xAxisVal == 1) {

                if (datad == "y") {
                } else {
                    if (slen >= 3) {
                        int index1 = datad.indexOf("y");
                        thodd = datad.substring(index1 - 3, index1);
                        vald = Integer.parseInt(thodd);
                        vald = vald - 360;
                        yaw = map(vald, 0, 360, 0, dartframe.getWidth());

                        yawRangeCheck = map(vald, 0, 360, -180, 180);
                        red_dart.setX((yaw) - red_dart.getWidth() / 2);
                        red_dart.setY((dartframe.getHeight() / 2) - (red_dart.getHeight() / 2));

                        String yawStr = Integer.toString((int) yawRangeCheck);
                        xAxisText.setText("X-Axis : " + yawStr);

                        if (yaw >= dartframe.getWidth() / 2 + n && yaw <= dartframe.getWidth() / 2 + n + blue_dart.getWidth() / 2) {

                            n = new Random().nextInt(rangeVal * 100) / 4;
                            if (random % 2 == 1) {
                                n = -n;
                            }
                            blue_dart.setY((dartframe.getHeight() / 2) - (blue_dart.getHeight() / 2));
                            blue_dart.setX((dartframe.getWidth() / 2) - (blue_dart.getWidth() / 2) + n);
                            random++;
                        }

                        if (yawRangeCheck <= -(rangeVal * 10)) {
                            rangeMin = 1;
                        }
                        if (yawRangeCheck >= (rangeVal * 10)) {
                            rangeMax = 1;
                        }

                        if (rangeMin == 1 && rangeMax == 1 && yawRangeCheck >= -10 && yawRangeCheck <= 10) {
                            rangeMax = 0;
                            rangeMin = 0;

                            repeatCountx++;
                            String repeatCountStr = Integer.toString(repeatCountx);

                            repeatText.setText("Repetation : " + repeatCountStr);
                        }

                        rollRangeCheck = 0;
                        pitchRangeCheck = 0;
                    }
                }
            }


            else if (zAxisVal == 1) {
                if (datad == "p") {
                } else {
                    if (slen >= 3) {
                        int index11 = datad.indexOf("p");
                        thoddy = datad.substring(index11 - 3, index11);
                        valdy = Integer.parseInt(thoddy);
                        valdy = valdy - 360;


                        roll = map(valdy, 0, 360, 0, dartframe.getWidth());
                        rollRangeCheck = map(valdy, 0, 360, -180, 180);
                        red_dart.setX((roll) - red_dart.getWidth() / 2);
                        red_dart.setY((dartframe.getHeight() / 2) - (red_dart.getHeight() / 2));


                        String rollStr = Integer.toString((int) rollRangeCheck);
                        zAxisText.setText("Z-Axis : " + rollStr);


                        if (rollRangeCheck <= -(rangeVal * 10)) {
                            rangeMin = 1;
                        }
                        if (rollRangeCheck >= (rangeVal * 10)) {
                            rangeMax = 1;
                        }

                        if (rangeMin == 1 && rangeMax == 1 && rollRangeCheck >= -10 && rollRangeCheck <= 10) {
                            rangeMax = 0;
                            rangeMin = 0;

                            repeatCounty++;
                            String repeatCountStr = Integer.toString(repeatCounty);

                            repeatText.setText("Repetation : " + repeatCountStr);
                        }

                        yawRangeCheck = 0;
                        pitchRangeCheck = 0;


                    }
                }
            }

            else if (yAxisVal == 1) {
                if (datad == "r") {
                } else {
                    if (slen >= 3) {
                        int index12 = datad.indexOf("r");
                        thodr = datad.substring(index12 - 3, index12);
                        valdr = Integer.parseInt(thodr);
                        valdr = valdr - 360;
                        pitch = map(valdr, 0, 360, 0, dartframe.getHeight());
                        pitchRangeCheck = map(valdr, 0, 360, -180, 180);
                        red_dart.setY((pitch) - red_dart.getHeight() / 2);
                        red_dart.setX(dartframe.getWidth() / 2 - (red_dart.getWidth() / 2));

                        String pitchStr = Integer.toString((int) pitchRangeCheck);
                        yAxisText.setText("Y-Axis : " + pitchStr);


                        if (pitchRangeCheck <= -(rangeVal * 10)) {
                            rangeMin = 1;
                        }
                        if (pitchRangeCheck >= (rangeVal * 10)) {
                            rangeMax = 1;
                        }

                        if (rangeMin == 1 && rangeMax == 1 && pitchRangeCheck >= -10 && pitchRangeCheck <= 10) {
                            rangeMax = 0;
                            rangeMin = 0;

                            repeatCountz++;
                            String repeatCountStr = Integer.toString(repeatCountz);

                            repeatText.setText("Repetation : " + repeatCountStr);
                        }
                        yawRangeCheck = 0;
                        rollRangeCheck = 0;

                    }
                }
            }
            else {
                red_dart.setX((dartframe.getHeight() / 2) - red_dart.getHeight() / 2);
                red_dart.setY((dartframe.getWidth() / 2) - red_dart.getWidth() / 2);
                blue_dart.setX((dartframe.getHeight() / 2) - blue_dart.getHeight() / 2);
                blue_dart.setY((dartframe.getWidth() / 2) - blue_dart.getWidth() / 2);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        String rangeValStr = Integer.toString((int) (rangeVal * 10));
        rangeValText.setText(rangeValStr);


//        editangle = map(valdy, 90, 270, 2000, 0);
//        //locationCarSprite = (int) map(vald, 90, 270, minXOnScreen, maxXOnScreen);
    }
}
