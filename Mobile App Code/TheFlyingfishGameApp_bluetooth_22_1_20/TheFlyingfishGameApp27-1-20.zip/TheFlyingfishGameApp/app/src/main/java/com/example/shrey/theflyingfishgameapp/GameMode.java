package com.example.shrey.theflyingfishgameapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.shrey.theflyingfishgameapp.shoottheflakup.ShootingGameActivity;
import com.mapzen.speakerbox.Speakerbox;

public class GameMode extends BaseActivity {

    TextView gametext;
    Button spider,dogandbone,space;
    private String patient_name,patient_name_replace;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_mode);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        // Set the content to appear under the system bars so that the
                        // content doesn't resize when the system bars hide and show.
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // Hide the nav bar and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);

        gametext=findViewById(R.id.gametext);
        dogandbone=findViewById(R.id.dogandbone);
        space=findViewById(R.id.space);
        spider=findViewById(R.id.spider);

        patient_name=getIntent().getStringExtra("patientName");



        Speakerbox speakerbox = new Speakerbox(getApplication());

        patient_name_replace=patient_name.replace("_"," ");

        speakerbox.play("lets play and enjoy");

        gametext.setText(" Let's play, " + patient_name_replace);

        space.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(GameMode.this,GameSetting.class);
                i.putExtra("patientName", patient_name);
                i.putExtra("gameNumber","2");
                startActivity(i);
            }
        });

        dogandbone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(GameMode.this,GameSetting.class);
                i.putExtra("patientName",patient_name);
                i.putExtra("gameNumber","1");
                startActivity(i);
            }
        });
        spider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(GameMode.this, GameSetting.class);
                i.putExtra("patientName",patient_name);
                i.putExtra("gameNumber","3");
                startActivity(i);
            }
        });
    }
}
